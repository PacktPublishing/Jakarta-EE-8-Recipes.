package org.packt.jakartaee8.vid08;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/trailer", asyncSupported=true)
public class TrailerServlet extends HttpServlet{
	
	 @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {

		 res.setContentType("text/plain");
		 res.addHeader("Transfer-Encoding", "chunked");
	     res.addHeader("TE", "trailers");
	     res.addHeader("Trailer", "data, key");
	       
	     StringBuilder sb = new StringBuilder();

	     InputStream input = req.getInputStream();
	     int b;
	     while ((b = input.read()) != -1) {
	         sb.append((char) b);
	     }
	        
	     String data1 = null;
	     String data2 = null;
	    
	     if (req.isTrailerFieldsReady()) {
	        Map<String, String> trailers = req.getTrailerFields();
	        System.out.println("Trailers" + trailers);
	        data1 = trailers.get("data1");
	        data2 = trailers.get("data2");
	     }
	     
	     final String allData = data1 + data2;
	     res.setTrailerFields(() -> {
	         Map<String, String> trailerData = new HashMap<>();
	         trailerData.put("key", "ABCG-TY");
	         trailerData.put("data", allData);
	         return trailerData;
	     });
	        
	     res.getWriter().write(sb.toString());
	        
	}

}
