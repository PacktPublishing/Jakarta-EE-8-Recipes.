package org.packt.jakartaee8.vid08;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/runsocket.html")
public class SocketClientServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/plain");
		
        String host = req.getServerName();
        int port = req.getServerPort();
              
        try (
        	Socket socket = new Socket(host, port);
        	OutputStream output = socket.getOutputStream();
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input))
        ) {
        	
            String reqStr = (new StringBuffer("POST /sec5tr/trailer HTTP/1.1\r\n")).
            append("Host: " + host + "\r\n").
            append("Content-Type: text/html\r\n" ).
            append("Transfer-Encoding: chunked\r\n").
            append("Connection: close\r\n").
            append("Trailer: Expires, data1, data2\r\n").
            append("\r\n").
            append("3\r\n").
            append("aye\r\n").
            append("0\r\n").
            append("Expires: Wed, 21 Oct 2015 07:28:00 GMT\r\n").
            append("data2: B\r\n").
            append("data1: A\r\n").
            append("\r\n").
            toString();
            
            output.write(reqStr.getBytes(Charset.forName("UTF-8")));
         
            String line = null;
	        while ((line = reader.readLine()) != null) {
				   res.getWriter().println(line);        
	        }
			
			
        }   
	}
}
