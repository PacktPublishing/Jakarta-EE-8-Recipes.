package org.packt.jakartaee8.vid06;

import java.util.List;

import org.packt.jakartaee8.vid05.Product;

public interface LocationDao {
	public void addLocation(Location loc);
	public long deleteLocation(Location loc);
	public long updateLocation(Location loc);
	public List<Location> listLocations();
	public List<Product> listProducts();
	public void addProduct(Product prod) throws Exception;

}
