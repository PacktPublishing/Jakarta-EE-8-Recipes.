package org.packt.jakartaee8.vid05;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Cache;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.persistence.config.HintValues;
import org.eclipse.persistence.config.QueryHints;

@Named(value="productDao")
@RequestScoped
public class ProductDaoImpl implements ProductDao {
	
	private static final Logger LOGGER = 
			  LogManager.getLogger(InventoryCustomLogger.class);
	
	@PersistenceContext(unitName="jakartaEEPU")
	private EntityManager em;
	 
	@Inject
	private UserTransaction utx;

	@Override
	public void addProduct(Product prod) {
		try {
			utx.begin();
			em.persist(prod);
			utx.commit();
			LOGGER.info("ProductDAO added product record.");
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em.clear();
		}
	}

	@Override
	public int deleteProduct(Product prod){
		try {
			utx.begin();
			em.remove(prod);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em.clear();
		}
		
		return prod.getId();
	}

	@Override
	public int updateProduct(Product prod){
		try {
			utx.begin();
			em.merge(prod);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em.clear();
		}
		
		return prod.getId();
	}

	@Override
	public List<Product> listProducts() {
		 Query query = em.createNamedQuery("inventory.listProds", Product.class)
				  .setHint(QueryHints.QUERY_RESULTS_CACHE, HintValues.TRUE);
		 List<Product> prods = query.getResultList();
		 for(Product p : prods) {
			 Cache eclipseL2Cache = em.getEntityManagerFactory().getCache();
			 System.out.println("Is Product ID: " + p.getId() + " cached? " 
			      + eclipseL2Cache.contains(Product.class,  p.getId()));
		 }
		 LOGGER.info("ProductDAO retrieved product records.");
		return prods;
	}

	@Override
	public Product getProduct(int id) {
		Query query = em.createNamedQuery("inventory.getProd");
		query.setParameter("id", id);
		Product p = (Product)query.getSingleResult();
		return p;
	}

	@Override
	public List<Double> unionMaxPrices(String name1, String name2) {
		List<Double> unionMaxPrices = em.createNativeQuery(
				"select max(price) from product where name like ? " + 
				"UNION select max(price) from product where name = ?")
					.setParameter("1", name1)
					.setParameter("2", name2)
				.getResultList();
		for(Object data : unionMaxPrices ) {
			System.out.println(data);
		}
		return unionMaxPrices;
	}

}
