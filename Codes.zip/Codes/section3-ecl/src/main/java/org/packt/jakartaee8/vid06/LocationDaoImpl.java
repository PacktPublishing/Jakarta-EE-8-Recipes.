package org.packt.jakartaee8.vid06;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Cache;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.persistence.config.HintValues;
import org.eclipse.persistence.config.QueryHints;
import org.packt.jakartaee8.vid05.InventoryCustomLogger;
import org.packt.jakartaee8.vid05.Product;

@Named(value="locationDao")
@RequestScoped
public class LocationDaoImpl implements LocationDao {
	
	private static final Logger LOGGER = 
			  LogManager.getLogger(InventoryCustomLogger.class);
	
	@PersistenceContext(unitName="jakartaEEPU")
	private EntityManager em1;
	
	@PersistenceContext(unitName="jakartaEEPULoc")
	private EntityManager em2;
	 
	@Inject
	private UserTransaction utx;

	@Override
	public void addLocation(Location loc){
		try {
			utx.begin();
			em2.persist(loc);
			utx.commit();
			LOGGER.info("LocationDAO added product record.");
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em2.clear();
		}

	}

	@Override
	public long deleteLocation(Location loc){
		try {
			utx.begin();
			em2.remove(loc);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em2.clear();
		}

		return loc.getId();
	}

	@Override
	public long updateLocation(Location loc){
		try {
			utx.begin();
			em2.merge(loc);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em2.clear();
		}
		return loc.getId();
	}

	@Override
	public List<Location> listLocations() {
		return em2.createQuery("SELECT l FROM Location l").getResultList();
	}

	@Override
	public List<Product> listProducts() {
		 Query query = em1.createNamedQuery("inventory.listProds", Product.class)
				  .setHint(QueryHints.QUERY_RESULTS_CACHE, HintValues.TRUE);
		 List<Product> prods = query.getResultList();
		 for(Product p : prods) {
			 Cache eclipseL2Cache = em1.getEntityManagerFactory().getCache();
			 System.out.println("Is Product ID: " + p.getId() + " cached? " 
			      + eclipseL2Cache.contains(Product.class,  p.getId()));
		 }
		 LOGGER.info("ProductDAO retrieved product records.");
		return prods;
	}
	
	@Override
	public void addProduct(Product prod) {
		try {
			utx.begin();
			em1.persist(prod);
			utx.commit();
			LOGGER.info("ProductDAO added product record.");
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em1.clear();
		}
	}


}
