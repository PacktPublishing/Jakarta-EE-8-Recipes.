/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical POJO when used in EJB session beans. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid05;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.annotations.CacheCoordinationType;
import org.eclipse.persistence.annotations.CacheType;

@Entity
@Table(name="product")
@Cacheable(value=true)
@Cache (type = CacheType.HARD_WEAK, alwaysRefresh = true, 
     coordinationType=CacheCoordinationType.INVALIDATE_CHANGED_OBJECTS)
@NamedQuery(name = "inventory.listProds", query = "SELECT p FROM Product p")
@NamedNativeQuery(name = "inventory.getProd", query = "select * from product where id = ?")
public class Product implements Serializable{
	
	@Id
	private Integer id;
    
    @Column
    @Basic(fetch=FetchType.LAZY)
  	private String name;
    
    @Column
	private Double price;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

}
