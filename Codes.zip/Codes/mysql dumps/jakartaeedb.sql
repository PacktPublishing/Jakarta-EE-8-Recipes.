-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: jakartaeedb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8mb4 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `jakartaeedb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `jakartaeedb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `jakartaeedb`;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,1,1),(2,2,1),(3,2,2);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `price` double(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (10,'Gems',68969.90),(1021,'Hershey\'s Choco',67898.90),(1067,'Bike',5678.00),(1134,'Sampler',1111.00),(2123,'Bike',5678.00),(2156,'Bike',56788.00),(10333,'Bike',5678.00),(10344,'Bike',1900.00),(10454,'Bike',1900.00),(10456,'Bike',5678.00),(10567,'567',134567.89),(21345,'Bike',1900.00),(21562,'Bike',56788.00),(32456,'Bike',1900.00),(35321,'Sampler',1111.00),(35621,'Sampler',1111.00),(45643,'Sampler',1111.00),(53453,'Bike',5678.00),(54331,'567',110000.67),(54332,'567',100000.67),(65789,'Bike',1900.00),(67667,'Bike',1900.00),(67678,'Bike',5678.00),(77654,'Bike',1900.00),(78945,'Bike',5678.00),(86764,'Bike',5678.00),(87999,'Bike',1900.00),(88765,'Bike',1900.00),(90389,'Sampler',1111.00),(98765,'Bike',1900.00),(101011,'Bike',5678.00),(101233,'Bike',5678.00),(102222,'hello',1900.00),(102346,'Bike',1900.00),(102356,'567',678.00),(103333,'Plate',1900.00),(103434,'Bike',1900.00),(104544,'Bike',1900.00),(104545,'Bike',1900.00),(104646,'Bike 2',2100.00),(105678,'Bike',1900.00),(106666,'hello',1900.00),(106789,'Bike',1900.00),(108665,'Plate',1900.00),(109800,'Bike',5678.00),(113156,'567',2456.98),(212134,'Bike',5678.00),(212344,'Bike',1900.00),(213121,'Bike',1200.60),(213345,'Sampler',1111.00),(213567,'Bike',5678.00),(214543,'Bike',1900.00),(214545,'Bike',1900.00),(215690,'567',1234.89),(217689,'Bike',5678.00),(218900,'Bike',5678.00),(234567,'Bike',1900.00),(237609,'Sampler',1111.00),(334323,'Bike 2',2100.00),(456900,'Corn',67898.90),(555567,'Bike',5678.00),(675889,'Bike',1900.00),(676767,'Bike 2',5678.00),(678907,'Bike',5678.00),(679999,'Bike',5678.00),(768934,'Bike',1900.00),(784738,'Cake',7890.78),(785959,'Corn',67898.90),(785969,'Mais',67898.90),(789008,'Bike',5678.00),(1045454,'Bike',1900.00),(1045669,'Bike',1900.00),(1056781,'Bike 2',5678.00),(1056782,'Bike 2',5678.00),(1056783,'Bike 2',5678.00),(1056785,'Bike 2',5678.00),(1056789,'Bike 2',5678.00),(1068699,'Bike',1900.00),(1111456,'Bike',5678.00),(2145454,'Bike',1900.00),(2167892,'Bike',5678.00),(2323345,'Salmon',6578.67),(3223455,'567',90878.56),(3343235,'Bike 2',2100.00),(3343236,'Bike 2',2100.00),(3343238,'Bike 2',2100.00),(4543321,'Sampler',1111.00),(6734556,'Bike',5678.00),(7465631,'Peanut Butter',67890.56),(7665609,'Sampler',1111.00),(9998865,'Bike',5678.00);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'administrator'),(2,'user');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(50) NOT NULL,
  `passphrase` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','admin','PBKDF2WithHmacSHA512:3072:HBM7AqTYFlGbgK0Y/bwZbD79cY6zW1Zi7XjdyCYl6U6ZOaf40UerJyNat8Mjxiy31f6wGBXStJuwnu+opp6PTw==:gmPH7Qiic8pmRvcxviwzVgZSqt1cdKUW5QlGmYNuCEs='),(2,'sjctrags','sjctrags','PBKDF2WithHmacSHA512:3072:o45Qx2IwLFo8k3Y2CinyitstUeGAm43z00OsqONDVpSamAht03PUij6UwTLqLh8a1SwSjBZWKTgJQ6tKSVXYEg==:fCbIXpyGm3/3urEfpE7TjYACo2MdFxYVOqqPSTDLSTM=');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-26 10:27:20
