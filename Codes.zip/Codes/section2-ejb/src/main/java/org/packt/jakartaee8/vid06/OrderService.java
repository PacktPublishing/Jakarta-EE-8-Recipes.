/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is the remote interface used in the JNDI access of the OrderServiceBean EJB.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.ejb.Remote;

@Remote
public interface OrderService {
	public void checkOut(Order order, Buyer buyer);
}
