/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This a sample implementation of some interceptor methods.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */


package org.packt.jakartaee8.vid02;

import java.io.Serializable;

import javax.annotation.Priority;
import javax.interceptor.AroundConstruct;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@ProdAnalytics
@Interceptor
@Priority(Interceptor.Priority.APPLICATION)
public class ProdAnalyticsInterceptor implements Serializable{
	
	 @AroundInvoke
     public Object invokeAveragePrice(InvocationContext ctx) throws Exception { 
		  System.out.println("ProdAnalyticsInterceptor averaging done by: " + ctx.getMethod());
		  return ctx.proceed();
	 }
	 
	 @AroundConstruct
	 public Object beforeInstantiation(InvocationContext ctx) throws Exception {
		 System.out.println("ProdAnalyticsInterceptor preparing: " + ctx.getConstructor() );
		 return ctx.proceed();
	 }
	
}
