/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is a sample EJB stateful EJB session bean.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.PostActivate;
import javax.ejb.PrePassivate;
import javax.ejb.Stateful;

@Stateful(name="productServiceFul")
public class ProductServiceFulBean implements ProductService{
	
	private List<Product> products;
	
	@PostConstruct
	public void init() {
		products = new ArrayList<>();
		System.out.println("intializing data resources");
	}
	
	@PreDestroy
	public void destroy() {
		products = null;
		System.out.println("destroying data resources");
	}
	
	@PostActivate
	public void startTransaction() {
		products = new ArrayList<>();
		System.out.println("method execution restarted...");
	}
	
	@PrePassivate
	public void endTransaction() {
		System.out.println("method execution pauses...");
	}
		
	
	public void addProduct(Product prod) {
		products.add(prod);
	}
	
	public void deleteProduct(Product prod) {
		products.remove(prod);
	}
	
	
	public List<Product> listProducts() {
		return products;
	}

}
