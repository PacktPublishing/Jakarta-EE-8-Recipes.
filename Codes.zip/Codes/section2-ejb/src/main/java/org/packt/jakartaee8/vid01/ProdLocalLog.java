/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements a singleton session bean that is invoked initially 
 *  upon servlet loading. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.util.List;

import javax.ejb.Singleton;
import javax.ejb.Startup;

@Singleton
@Startup
public class ProdLocalLog {
	
	public void logProducts(List<Product> prod) {
		prod.stream().map((p) -> p.getId()+ ":" 
						+ p.getName() + ":" 
						+ p.getPrice())
		             		.forEach(System.out::println);
	}

}
