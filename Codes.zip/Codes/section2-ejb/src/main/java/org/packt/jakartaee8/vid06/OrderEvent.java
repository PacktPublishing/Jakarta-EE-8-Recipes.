/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A class that depict an order event. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

public class OrderEvent {
	
	private String salesId;
	private Order order;
	private Buyer buyer;
	
	public OrderEvent(Order order, Buyer buyer, String salesId) {
		this.salesId = salesId;
		this.order = order;
		this.buyer = buyer;
	}
	
	public String getSalesId() {
		return salesId;
	}
	
	public Order getOrder() {
		return order;
	}
	
	public Buyer getBuyer() {
		return buyer;
	}

}
