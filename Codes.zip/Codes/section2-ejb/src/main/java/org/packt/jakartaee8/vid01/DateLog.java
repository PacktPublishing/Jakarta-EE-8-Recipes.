/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements session scoped beans with a custom qualifier name. 
 * 	It also highlights the use of container event and Project Lombok DI.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import lombok.Getter;

@Named("dateLog")
@SessionScoped
public class DateLog implements Serializable{
	
	private static final long serialVersionUID = -4040231747365922408L;
	
	@Getter
	private Date today;
	
	@PostConstruct
	public void initDate() {
		today = new Date();
		System.out.println("product transaction date: " + today);
	}
	
}
