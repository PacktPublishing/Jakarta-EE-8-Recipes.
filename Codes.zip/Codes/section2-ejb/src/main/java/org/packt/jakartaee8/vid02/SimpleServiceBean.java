/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is a sample EJB stateless EJB session bean
 *  with an interceptor.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */
package org.packt.jakartaee8.vid02;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

@Stateless
@Interceptors(value= {OldInterceptorSpec.class})
public class SimpleServiceBean implements SimpleService{
	
	@Override
	public void loadResources() {
		System.out.println("loading XML files.");	
	}
		
	public void cleanResources() {
		System.out.println("deleting loaded XML files.");
	}

}
