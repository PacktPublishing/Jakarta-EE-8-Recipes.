/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A sample Observer class that is invoked 
 *  ASYNCHRONOUSLY.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */ 
package org.packt.jakartaee8.vid07;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;

@RequestScoped
public class OrderClosedObserver {
	
	public void proceedOrderLog(@ObservesAsync OrderClosedEvent event) {
		System.out.println(event.getMessage());
	}

}
