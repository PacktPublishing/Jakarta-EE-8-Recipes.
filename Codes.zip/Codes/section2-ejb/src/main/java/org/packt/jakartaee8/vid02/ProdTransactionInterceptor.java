/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This a sample implementation of some interceptor methods.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid02;

import javax.annotation.Priority;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.packt.jakartaee8.vid01.Product;

@Interceptor
@ProdTransactions
@Priority(Interceptor.Priority.APPLICATION)
public class ProdTransactionInterceptor {
	 
	 @AroundInvoke
     public Object checkNewProduct(InvocationContext ctx) throws Exception { 
		 System.out.println("ProdTransactionInterceptor: " + ctx.getMethod());
		 Object parameters[] = ctx.getParameters();
		 if(parameters.length == 1 && parameters[0] instanceof Product) {
			  Product prod = (Product) parameters[0];
			  System.out.println("----------product to be added: " + prod.getName());
		 }
		 return ctx.proceed();
	 }
	 
}
