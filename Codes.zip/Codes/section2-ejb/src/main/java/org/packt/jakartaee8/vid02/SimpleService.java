/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is the remote interface used in the JNDI access of the 
 *  ProductServiceBean EJB.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid02;

import javax.ejb.Remote;

@Remote
public interface SimpleService {
	public void loadResources() ;
	public void cleanResources();
}
