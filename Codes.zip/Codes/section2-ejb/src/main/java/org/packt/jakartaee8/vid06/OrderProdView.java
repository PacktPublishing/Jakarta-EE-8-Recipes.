/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A servlet controller that accepts 3 request parameters needed by the product order services.
 *  This also highlights EJB stateful session bean.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import java.io.IOException;

import javax.inject.Inject;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.packt.jakartaee8.vid07.AuditLogTransaction;

@WebServlet("/orderview.html")
public class OrderProdView extends HttpServlet{
	
	private OrderService orderService;
	
	@Inject
	private AuditLogTransaction auditLogTransaction;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		String qty = req.getParameter("qty");
		String mobile = req.getParameter("mobile");
		
		Integer prodId = Integer.parseInt(id);
		Integer qtyInt = Integer.parseInt(qty);
		
		Order order = new Order();
		order.setProdId(prodId);
		order.setQty(qtyInt);
		
		Buyer buyer = new Buyer();
		buyer.setMobile(mobile);
		
		try {
			InitialContext ic=new InitialContext();
			Object obj= (OrderService)ic.lookup("java:app/sec2ejb/orderService");       		
			orderService=(OrderService) obj;
			System.out.println("order service bean object ID: " + orderService.hashCode());
						
		}catch(NamingException ex) {
			req.getRequestDispatcher("/orderform.html").forward(req, resp);
		}
		
		orderService.checkOut(order, buyer);
		auditLogTransaction.proceedOrderAsync("order is now ready for delivery...");
		req.getRequestDispatcher("/vid06/order_view.jsp").include(req, resp);
	}
}
