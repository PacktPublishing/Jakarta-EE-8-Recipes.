/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the Login View controller with a highlight on
 *  injecting EJB session bean from local cache or remotely using InitialContext.
 *  Explains also the behavior of EJB session bean instantiation.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.io.IOException;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/prodview.html")
public class ProductResultView extends HttpServlet{
	
	private ProductService productService;
	
	@EJB
	private ProdLocalLog prodLocalLog;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		Double price = Double.parseDouble(req.getParameter("price"));
		
		try {
			InitialContext ic=new InitialContext();
			Object obj= (ProductService)ic.lookup("java:app/sec2ejb/productService");       		
			productService=(ProductService) obj;
			System.out.println("session bean object ID: " + productService.hashCode());
		 }catch(NamingException ex) {
			req.getRequestDispatcher("/prodform.html").forward(req, resp);
		 }
		
		Product prod = new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		
		productService.addProduct(prod);
		req.setAttribute("products", productService.listProducts());
		
		prodLocalLog.logProducts(productService.listProducts());
	    req.getRequestDispatcher("/vid01/prod_view.jsp").forward(req, resp);
	}

}
