/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A sample Observer class that is triggered when the OrderEvent is fired.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.annotation.Priority;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;

@RequestScoped
public class SalesNotifyObserver {
	
	public void notifyManager(@Observes @Priority(2) OrderEvent event) {
		System.out.println("Please acknowledge sales invoice of : " + event.getBuyer().getMobile());
	}
}
