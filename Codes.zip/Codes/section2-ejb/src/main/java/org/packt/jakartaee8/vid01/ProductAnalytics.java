/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements session scoped beans with a qualifier name. 
 * 	It also highlights the use of Java Streams, container event and Project Lombok DI.
 *  This class can also be decorated with interceptor qualifiers.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import org.packt.jakartaee8.vid02.InterceptProcA;
import org.packt.jakartaee8.vid02.InterceptProcB;
import org.packt.jakartaee8.vid02.ProdAnalytics;

import lombok.Getter;

@InterceptProcA
@InterceptProcB
@ProdAnalytics
@Named("analytics")
@RequestScoped
public class ProductAnalytics {
	
	@Getter
	private double priceAve;
	
	
	public void avePrice(List<Product> prod) {
		priceAve = prod.stream()
				.mapToDouble(Product::getPrice)
				.average()
				.getAsDouble();
	}
}
