/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is a sample EJB stateless EJB session bean.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

import org.packt.jakartaee8.vid02.ProdTransactions;

@Stateless(name="productService")
public class ProductServiceBean implements ProductService{
	
	private List<Product> products;
	private ProductAnalytics prodAnalystics;
	
	@Inject
	public ProductServiceBean(@Named("analytics") ProductAnalytics prodAnalystics) {
		this.prodAnalystics = prodAnalystics;
	}
	
		
	@PostConstruct
	public void init() {
		products = new ArrayList<>();
		System.out.println("intializing data resources");
	}
	
	
	@PreDestroy
	public void destroy() {
		products = null;
		System.out.println("destroying data resources");
	}
	
	@ProdTransactions
	public void addProduct(Product prod) {
		products.add(prod);
		prodAnalystics.avePrice(products);
	}
	
	public void deleteProduct(Product prod) {
		products.remove(prod);
	}
		
	public List<Product> listProducts() {
		return products;
	}
}
