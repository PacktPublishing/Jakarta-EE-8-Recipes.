/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the Product Form controller with multiple 
 *  responses using PushBuilder. 
 * 	It also pushes web resources such as JS and CSS into the browser cache 
 *  for page loading performance.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.io.IOException;
import java.util.Optional;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.packt.jakartaee8.vid02.SimpleService;

@WebServlet("/prodform.html")
public class ProductFormController extends HttpServlet{
	
	@EJB
	private SimpleService simpleServiceBean;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		simpleServiceBean.loadResources();
		Optional.ofNullable(req.newPushBuilder())
		.ifPresent(pb ->{
			pb.path("js/jquery.min.js")
                .addHeader("content-type", "application/javascript")
                .path("js/bootstrap.min.js")
				.addHeader("content-type", "application/javascript")
				.path("js/npm.js")
				.addHeader("content-type", "application/javascript")
				.path("css/bootstrap.min.css")
				.addHeader("content-type", "text/css")
                .push();
		});
		simpleServiceBean.cleanResources();
		req.getRequestDispatcher("/vid01/prod_form.jsp").forward(req, resp);
	}
	
}
