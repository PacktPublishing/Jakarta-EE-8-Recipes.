/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is a sample EJB stateful EJB session bean that fires an event SYNCHRONOUSLY.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.ejb.Stateful;
import javax.enterprise.event.Event;
import javax.inject.Inject;

@Stateful(name="orderService")
public class OrderServiceBean implements OrderService {
		
	@Inject
    private Event<OrderEvent> event;

	@Override
	public void checkOut(Order order, Buyer buyer) {
		Integer salesId = (int)(Math.random()*100000);
		System.out.println("Finishing Checkout with Sales Id: " + salesId);
        event.fire(new OrderEvent(order, buyer, salesId+""));
	}
}
