/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This a sample implementation of some interceptor methods.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid02;

import java.io.Serializable;

import javax.annotation.Priority;
import javax.interceptor.AroundConstruct;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@InterceptProcB
@Interceptor
@Priority(Interceptor.Priority.APPLICATION + 800)
public class InvokeBInterceptor implements Serializable{
	
	@AroundConstruct
	public Object beforeInstantiation(InvocationContext ctx) throws Exception {
		 System.out.println("InvokeBInterceptor for : " + ctx.getConstructor() );
		 return ctx.proceed();
	}
	
	@AroundInvoke
	public Object cutAnyMethod(InvocationContext ctx) throws Exception {
		System.out.println("InvokeBInterceptor for : " + ctx.getMethod() );
		return ctx.proceed();	 
	}

}
