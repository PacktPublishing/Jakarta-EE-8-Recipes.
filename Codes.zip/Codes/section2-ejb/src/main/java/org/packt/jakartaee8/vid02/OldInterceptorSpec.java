/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This a sample implementation of some interceptor methods.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */


package org.packt.jakartaee8.vid02;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class OldInterceptorSpec {
	
	@AroundInvoke
	public Object interceptMethod(InvocationContext ctx) throws Exception{
		System.out.println("running around method: " + ctx.getMethod());
		System.out.println("with no. of parameters: " + ctx.getParameters().length);
		return ctx.proceed();
	}
	
	@PostConstruct
	public void interceptConstructor(InvocationContext ctx) throws Exception{
		System.out.println("running post construct...");
	}
	
	@PreDestroy
	public void interceptBeforeExit(InvocationContext ctx) throws Exception{
		System.out.println("running pre-destroy...");
	}
	
}
