****************************************************************
                           DESCRIPTION
****************************************************************
These are the codes implemented, created, used, and demonstrated
in the Section 2 videos. Running these whole project will give 
you unwanted results. So run and test each package one at a time 
or separately.
****************************************************************
                           TOOLS
****************************************************************
 - Java version used is Java 10
 - Application server used is Apache TomEE 8
 - No database back-end

