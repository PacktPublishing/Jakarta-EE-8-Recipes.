/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical session-scoped object
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */


package org.packt.jakartaee8.vid08;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class DataRepo implements Serializable{

	private static final long serialVersionUID = -1065178047282046400L;

	private String footer;
	
	private List<Product> prods;
	
	private List<User> users;
		
	@PostConstruct
	public void initData() {
		footer = "MVC 1.0 Eclipse Ozark";
		prods = new ArrayList<>();
		users = new ArrayList<>();
	}
	
	public String getFooter() {
		return footer;
	}
	
	public void setFooter(String footer) {
		this.footer = footer;
	}
	
	public List<Product> getProds(){
		return this.prods;
	}
	
	public void addProd(Product p) {
		prods.add(p);
	}
	
	public List<User> getUsers(){
		return users;
	}
	
	public void addUser(User u) {
		users.add(u);
	}
	

}
