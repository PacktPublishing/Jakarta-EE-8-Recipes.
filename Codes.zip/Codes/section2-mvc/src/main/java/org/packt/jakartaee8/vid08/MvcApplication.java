/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	The Application bootstrap class for the RestEasy.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationScoped
@ApplicationPath("packt")
public class MvcApplication extends Application {
	
}
