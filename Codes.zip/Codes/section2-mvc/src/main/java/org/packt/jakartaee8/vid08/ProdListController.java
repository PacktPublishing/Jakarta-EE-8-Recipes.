package org.packt.jakartaee8.vid08;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.mvc.Controller;
import javax.mvc.Models;
import javax.mvc.View;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@RequestScoped
@Path("products")
@Controller
public class ProdListController {

    @Inject
    private Models models;

    @GET
    @View("thymeleaf/products.html")
    @Path("/listprods")
    public void getProds() {
        
        List<Product> prods = new ArrayList<>();
        prods.add(new Product(101, "Pencil", 56.90));
        prods.add(new Product(102, "Manila Paper", 100.90));
        prods.add(new Product(111, "Candy", 3.5));
        prods.add(new Product(657, "Bag", 6000.89));
        prods.add(new Product(800, "Shoes", 2456.90));
        
        models.put("products", prods);
        models.put("title", "List of Products");
    }
}