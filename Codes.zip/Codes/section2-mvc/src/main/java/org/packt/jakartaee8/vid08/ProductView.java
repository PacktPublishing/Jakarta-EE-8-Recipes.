/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	The view component calling the result page.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.mvc.Controller;
import javax.mvc.Models;
import javax.mvc.View;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@RequestScoped
@Controller
@Path("/prodview")
public class ProductView {
	
	@Inject
	private DataRepo dataRepo;
	
	@Inject
	private Models models;

	@POST
	@View("product/prod_view.jsp")
	public void submit(@FormParam("id") Integer id, 
					   @FormParam("name") String name,
					   @FormParam("price") Double price) {
		Product p = new Product();
		p.setId(id);
		p.setName(name);
		p.setPrice(price);
		
		System.out.println(id);
		
		dataRepo.addProd(p);
		models.put("footer", dataRepo.getFooter());
		models.put("prods", dataRepo.getProds());
	}

}
