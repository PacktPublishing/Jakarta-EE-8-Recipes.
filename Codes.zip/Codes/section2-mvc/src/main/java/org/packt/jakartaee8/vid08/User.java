/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A form backing object.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import java.io.Serializable;

import javax.ws.rs.FormParam;

public class User implements Serializable {

	
	private static final long serialVersionUID = 3779234583998881785L;

	@FormParam("username")
	private String username;
	
	@FormParam("password")
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
