/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	Another view component using the @FormBean
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.mvc.Controller;
import javax.mvc.Models;
import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@RequestScoped
@Controller
@Path("/userview")
public class UserView {
	
	@Inject
	private DataRepo dataRepo;
	
	@Inject
	private Models models;
	
	@POST
	public Response submit(@BeanParam User user) {
		dataRepo.addUser(user);	
		
		models.put("footer", dataRepo.getFooter());
		models.put("users", dataRepo.getUsers());
		return Response.status(Response.Status.OK).entity("user/user_view.jsp").build();
	}

}
