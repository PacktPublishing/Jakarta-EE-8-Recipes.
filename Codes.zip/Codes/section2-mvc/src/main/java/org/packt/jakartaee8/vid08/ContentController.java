/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	The main controller of this application. It contains the following:
 *    (a) how to build a controller class for Krazzo
 *    (b) how to inject the model objects to Models API
 *    (c) three ways how to implement views --- ( all view pages must be located by default at /WEB-INF/views folder)
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.mvc.Controller;
import javax.mvc.Models;
import javax.mvc.View;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.mvcspec.ozark.engine.Viewable;

@RequestScoped
@Path("/content")
@Controller
public class ContentController {
	
	@Inject
	private Models models;
	
	@Inject
	private DataRepo dataRepo;
		
	@GET
	@Path("/welcome/{name}")
	public String welcome(@PathParam("name") String name) {
		System.out.println("welcome page online....");
		models.put("title", "Eclipse Krazo");
		models.put("name", name);
		dataRepo.setFooter("Call Administrator for assistance.");
		return "welcome.jsp";
	}
	
	@GET
	@Path("/intro")
	public Viewable intro() {
		System.out.println("introduction page....");
		models.put("title", "Eclipse Krazo");
		return new Viewable("intro.jsp", models);
	}
	
	@GET
	@Path("/goodbye")
	@View("bye.jsp")
	public void bye() {
		System.out.println("goodbye page online....");
	}
	
	@GET
	@Path("/error")
	public Response error(@QueryParam("code") Integer errCode, 
			              @QueryParam("message") String errMsg) {
		models.put("code", errCode);
		models.put("message", errMsg);
		return Response.status(Response.Status.OK).entity("error.jsp").build();
	}

}
