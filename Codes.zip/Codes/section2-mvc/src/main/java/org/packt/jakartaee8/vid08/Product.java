/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	The typical POJO class.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import java.io.Serializable;

public class Product implements Serializable{
	
	
	private static final long serialVersionUID = -1373349275183193254L;

	private Integer id;
	private String name;
	private Double price;
	
	public Product() {	}
	
	public Product(Integer id, String name, Double price) {	
		this.id = id;
		this.name = name;
		this.price = price;
	}
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

}
