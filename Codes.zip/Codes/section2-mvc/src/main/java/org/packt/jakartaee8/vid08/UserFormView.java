/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	Another form controller using the @BeanParam
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import javax.enterprise.context.RequestScoped;
import javax.mvc.Controller;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@RequestScoped
@Controller
@Path("/userform.html")
public class UserFormView {
	
	@GET
	public String initForm() {
		return "user/user_form.jsp";
	}

}
