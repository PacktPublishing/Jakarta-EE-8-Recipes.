/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	The typical form controller showcasing @FormParam
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 6, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import javax.enterprise.context.RequestScoped;
import javax.mvc.Controller;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@RequestScoped
@Controller
@Path("/prodfrm.html")
public class ProductFormView {
	
	@GET
	public String initForm() {
		return "product/prod_form.jsp";
	}

}
