/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical POJO when used in EJB session beans. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;

@Entity
@Table(name = "product")
public class Product implements Serializable{
	
	@Id
	@PositiveOrZero
	private Integer id;
    	
    @Column(name="name", nullable=false)
	@NotBlank
    private String name;
    
    @Column(name="price", nullable=false, precision=2)
    @ProdPrice(value = 5000.00)
    private Double price;
    
    @Transient
    private LocalDate supplied;
    
    public LocalDate getSupplied() {
		return supplied;
	}
	public void setSupplied(LocalDate supplied) {
		this.supplied = supplied;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
}
