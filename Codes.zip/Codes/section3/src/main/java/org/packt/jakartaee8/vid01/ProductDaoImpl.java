package org.packt.jakartaee8.vid01;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

@Named(value="productDao")
@RequestScoped
public class ProductDaoImpl implements ProductDao {
	
	private EntityManagerFactory  emf;
	private EntityManager em;
	private EntityTransaction et;
	
	@PostConstruct
	public void init() {
		emf = Persistence.createEntityManagerFactory("jakartaEEPU");
	}
		
	@Inject
    private Validator validator;
	
 
	@Override
	public void addProduct(Product prod){
		em = emf.createEntityManager();
		et = em.getTransaction();
		try {
			et.begin();
			em.persist(prod);
			et.commit();
		} catch (ConstraintViolationException e) {
			try {
				et.rollback();
				Set<ConstraintViolation<Product>> violations = validator.validate(prod);
				for (ConstraintViolation<Product> violation : violations) {
				    System.out.println("Invalid input: " + violation.getInvalidValue()); 
				}		
			}  catch (Exception e1) {
				e.printStackTrace();
			}
				
		} catch (Exception e) {
			try {
				et.rollback();
			}  catch (Exception e1) {
				e.printStackTrace();
			}
		} finally {
			em.close();
		}
	}

	@Override
	public int deleteProduct(Product prod){
		em = emf.createEntityManager();
		et = em.getTransaction();
		try {
			Product pToDel = em.find(Product.class, prod.getId());
			et.begin();
			em.remove(pToDel);
			et.commit();
		} catch (ConstraintViolationException e) {
			try {
				et.rollback();
				Set<ConstraintViolation<Product>> violations = validator.validate(prod);
				for (ConstraintViolation<Product> violation : violations) {
				    System.out.println(violation.getInvalidValue()); 
				}		
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}			
		} catch (Exception e) {
			try {
			   et.rollback();
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}
		} finally {
			em.close();
		}
		return prod.getId();
	}

	@Override
	public int updateProduct(Product prod) {
		em = emf.createEntityManager();
		et = emf.createEntityManager().getTransaction();
		try {
			et.begin();
			em.merge(prod);
			et.commit();
		} catch (ConstraintViolationException e) {
			try {
				et.rollback();
				Set<ConstraintViolation<Product>> violations = validator.validate(prod);
				for (ConstraintViolation<Product> violation : violations) {
				    System.out.println(violation.getInvalidValue()); 
				}		
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}					
		} catch (Exception e) {
			try {
				et.rollback();
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}
		} finally {
			em.close();
		}
		return prod.getId();
	}

	@Override
	public List<Product> listProducts() {
		em = emf.createEntityManager();
		List<Product> prods = em.createQuery("SELECT p FROM Product p").getResultList();
		em.close();
		return prods;
	}

	@Override
	public List<String> listProdNames() {
		em = emf.createEntityManager();
		Stream<Product> books = 
				em.createQuery("SELECT p FROM Product p", Product.class)
				.getResultStream(); 
		em.close();
		return books.map((p) -> p.getName()).distinct().collect(Collectors.toList());
	}

}
