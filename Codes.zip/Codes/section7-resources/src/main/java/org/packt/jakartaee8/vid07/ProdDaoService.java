package org.packt.jakartaee8.vid07;

import java.util.List;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

@Path("/dao")
@Stateless
@DeclareRoles({"user", "administrator", "guest"})
@RolesAllowed(value= {"administrator", "user"})
public class ProdDaoService {
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@GET
	@Path("/product/list")
    @Produces(MediaType.APPLICATION_JSON)
	@RolesAllowed(value= {"administrator", "user"})
    public List<Product> listProducts() {
        return productDao.listProducts();
    }
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("/product/filter/{id}")
	@RolesAllowed(value= {"administrator"})
    public Product filterProduct(@PathParam("id") int id) {
		return productDao.getProduct(id);
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/remove/{id}")
	@RolesAllowed(value= {"administrator"})
	public Product removeProduct(@PathParam("id") int id) {
		Product delProd = new Product();
		try {
			delProd = productDao.getProduct(id);
			productDao.deleteProduct(id);
		} catch (Exception e) {	}
		 
		return delProd;
	 }

	 @PUT
	 @Consumes(MediaType.APPLICATION_JSON)
	 @Path("/product/update")
	 @RolesAllowed(value= {"administrator"})
	 public Product updateProduct(Product prod) {
		 try {
			productDao.updateProduct(prod);
		} catch (Exception e) {
			
		}
		 return prod;
	 }
	 
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/addjson")
	@RolesAllowed(value= {"administrator"})
	public Product addProductJson(Product prod) {
		try {
			productDao.addProduct(prod);
		} catch (Exception e) {	}
		return prod;
	}
	 
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/addform")
	@RolesAllowed(value= {"administrator"})
	public Product addProduct(MultivaluedMap<String, String> params) {
		Product prod = new Product();
		try {
			prod.setId(Integer.parseInt(params.getFirst("id")));
			prod.setName(params.getFirst("name"));
			prod.setPrice(Double.parseDouble(params.getFirst("price")));
			productDao.addProduct(prod);
		} catch (Exception e) {	}
		return prod;
	 }
			

	 @PATCH
	 @Consumes(MediaType.APPLICATION_JSON)
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/product/filter/patch/{id}")
	 @RolesAllowed(value= {"administrator", "user"})
	 public Product filterPatchProduct(Product prod, 
			 @PathParam("id") Integer id) {
	     try {
	    	prod.setId(id);
	    	System.out.println(prod);
			productDao.updateProduct(prod);
		} catch (Exception e) {	}
		 return productDao.getProduct(id);
	 }
	 
	 
	 



}
