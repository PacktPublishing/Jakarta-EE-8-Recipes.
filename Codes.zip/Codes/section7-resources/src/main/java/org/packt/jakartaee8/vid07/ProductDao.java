/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is the remote interface used in the JNDI access of the ProductServiceBean EJB.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid07;

import java.util.List;

public interface ProductDao {
	public void addProduct(Product prod) throws Exception;
	public int deleteProduct(int id) throws Exception;
	public int updateProduct(Product prod) throws Exception;
	public List<Product> listProducts() ;
	public Product getProduct(int id);
}
