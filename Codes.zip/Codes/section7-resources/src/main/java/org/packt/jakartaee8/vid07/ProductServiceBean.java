/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is a sample EJB stateless EJB session bean.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid07;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;

@Stateless(name="productService")
@DeclareRoles({"user", "administrator", "guest"})
@PermitAll
public class ProductServiceBean implements ProductService{
	
	private List<Product> products;
	
	@PostConstruct
	public void init() {
		products = new ArrayList<>();
		System.out.println("intializing data resources");
	}
	
	
	@PreDestroy
	public void destroy() {
		products = null;
		System.out.println("destroying data resources");
	}
	
	@RolesAllowed("administrator")
	public void addProduct(Product prod) {
		products.add(prod);
		
	}
	
	@RolesAllowed("administrator")
	public void deleteProduct(Product prod) {
		products.remove(prod);
	}
	
	@RolesAllowed("user")
	public List<Product> listProducts() {
		return products;
	}
}
