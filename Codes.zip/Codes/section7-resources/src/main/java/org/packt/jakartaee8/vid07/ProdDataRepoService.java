package org.packt.jakartaee8.vid07;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Path("/repo")
@Stateless
@DeclareRoles({"user", "administrator", "guest"})
@RolesAllowed(value= {"administrator", "user"})
public class ProdDataRepoService {
	
	@Context
	private HttpServletRequest req;
	
	@GET
	@Path("/strdata")
    @Produces(MediaType.TEXT_PLAIN)
	public String getData() {
		if(req.isUserInRole("administrator")) {
			return new String("JakartaEE Administrator");
		} else if (req.isUserInRole("user")){
			return new String("JakartaEE User ");
		}
		return new String("Restricted...");
		
    }
	
	@GET
	@Path("/arrdata")
    @Produces(MediaType.APPLICATION_JSON)
	@RolesAllowed(value= {"administrator"})
    public String[] listStringArray() {
        return new String[]{"I", "LOVE", "JAKARTAEE", "."};
    }
	
	@GET
	@Path("/listdata")
    @Produces(MediaType.APPLICATION_JSON)
	@RolesAllowed(value= {"administrator"})
    public List<String> listData() {
        List<String> listStr = new ArrayList<>();
        listStr.add("I");
        listStr.add("LOVE");
        listStr.add("JAKARTEE");
        listStr.add(".");
        return listStr;
    }
			
	@GET
	@Path("/product")
    @Produces(MediaType.APPLICATION_JSON)
	@RolesAllowed(value= {"administrator"})
    public Product generateJson() {
		Product product = new Product();
		product.setId(101);
		product.setName("Maling");
		product.setPrice(67869.89);
		
		return product;
    }
	
	
	
	
	
	
	
}
