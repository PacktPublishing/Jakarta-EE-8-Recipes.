package org.packt.jakartaee8.vid02;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Default;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.IdentityStore;

@Default
@ApplicationScoped
public class ContentAuthIdentityStore implements IdentityStore {
	
	private Map<String, String> users;
	private Map<String, Set<String>> roles;
	
	@PostConstruct
	public void init() {
		users = new HashMap<>();
		roles = new HashMap<>();
		users.put("admin", "admin");
		users.put("sjctrags", "sjctrags");
		users.put("guest", "guest");
		
		roles.put("admin", new HashSet<>(Arrays.asList("administrator")));
		roles.put("sjctrags", new HashSet<>(Arrays.asList("user")));
		roles.put("guest", new HashSet<>(Arrays.asList("guest")));
	}
	 
    public CredentialValidationResult validate(UsernamePasswordCredential usernamePasswordCredential) {
    	 String caller = usernamePasswordCredential.getCaller();
    	 String pwd = usernamePasswordCredential.getPasswordAsString(); 
    	 if(users.containsKey(caller)  ) {
    		 if(users.get(caller).equals(pwd)) {
    			 System.out.println("ContentAuthIdentityStore: " + caller);
    			 return new CredentialValidationResult(caller);
    		 }
    	 }
    
        return CredentialValidationResult.INVALID_RESULT;
    }

}
