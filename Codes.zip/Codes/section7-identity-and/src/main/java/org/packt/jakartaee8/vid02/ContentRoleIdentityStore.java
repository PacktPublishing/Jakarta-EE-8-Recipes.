package org.packt.jakartaee8.vid02;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Default;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.IdentityStore;

@Default
@ApplicationScoped
public class ContentRoleIdentityStore implements IdentityStore{
		
	private Map<String, Set<String>> roles;
	
	@PostConstruct
	public void init() {
		roles = new HashMap<>();
		roles.put("admin", new HashSet<>(Arrays.asList("administrator")));
		roles.put("sjctrags", new HashSet<>(Arrays.asList("user")));
		roles.put("guest", new HashSet<>(Arrays.asList("guest")));
	}
	
   @Override
   public Set<String> getCallerGroups(CredentialValidationResult validationResult) {
	   System.out.println("ContentRoleIdentityStore: " + roles.get(validationResult.getCallerPrincipal().getName()));
	   return roles.get(validationResult.getCallerPrincipal().getName());
   }
   
   @Override
   public Set<ValidationType> validationTypes() {
	   return new HashSet<>(Arrays.asList(ValidationType.PROVIDE_GROUPS));
   }
   
}
