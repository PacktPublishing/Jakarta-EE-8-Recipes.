package org.packt.jakartaee8.vid06;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.sse.OutboundSseEvent;
import javax.ws.rs.sse.Sse;
import javax.ws.rs.sse.SseEventSink;

@Path("/sse")
@RequestScoped
public class SseProductService {
	
	@Context
    private Sse sse;
	
	@Inject
	private ProductDaoImpl productDaoImpl;
	
	private Executor executorService = 
			Executors.newSingleThreadExecutor();
		
	@GET
    @Path("/intdata")
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void sendIntEvents(@Context SseEventSink sseEventSink) {
    	CompletableFuture<Void> runStrEvent = 
    			CompletableFuture.runAsync(()->{
    				OutboundSseEvent event = sse.newEventBuilder()
		  				.id(UUID.randomUUID().toString())
		  				.name("random")
		  				.mediaType(MediaType.TEXT_PLAIN_TYPE)
		  				.data(Integer.class, (int)((Math.random()*100)+2000))
		  				.reconnectDelay(6)
		  				.build();
    					System.out.println("sending a random number...");
    				sseEventSink.send(event);
    				try {
    					Thread.sleep(1000);
    				} catch (InterruptedException ex) {
    					System.out.println(ex.getMessage());
    				}
    	}); 
    	runStrEvent.whenComplete((resp, ex)->{
    		System.out.println("done server sent...");;
    	});
    	
    }
	
	@GET
    @Path("/strdata")
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void sendSeveralEvents(@Context SseEventSink sseEventSink) {
    	executorService.execute(() -> {
    	    	sseEventSink.send(sse.newEvent("product1", "Bike"));
    	    	sseEventSink.send(sse.newEvent("product2", "Plate"));
    	    	sseEventSink.send(sse.newEvent("product3", "Apple"));
    	});
    }
	
	@GET
    @Path("/prodjson/{id}")
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void sendEventsJson(@PathParam("id") Integer id, @Context SseEventSink sseEventSink) {
    	Product prod = productDaoImpl.getProduct(id);
    	CompletionStage<Void> runProdEvent =
    			CompletableFuture.runAsync(()->{
    				OutboundSseEvent prodEvent = sse.newEventBuilder()
		  				.name("product")
                        .mediaType(MediaType.APPLICATION_JSON_TYPE)
                        .data(Product.class, prod)
                        .build();
    				System.out.println("sending product record...");
    				sseEventSink.send(prodEvent);

    				try {
    					Thread.sleep(1000);
    				} catch (InterruptedException ex) {
    					System.out.println(ex.getMessage());
    				}
    		}); 
    	runProdEvent.whenComplete((resp, ex)->{
    		System.out.println("done server sent...");
    	});
    }
	
	@GET
    @Path("/prodjson/list")
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void loopEvents(@Context SseEventSink sseEventSink) {
    	List<Product> prods = productDaoImpl.listProducts(); 
        executorService.execute(() -> {
            for(Product prod : prods) {
                try {
                    TimeUnit.SECONDS.sleep(5);
                    System.out.println("Sending product: " + prod.getId());
                    OutboundSseEvent prodEvents = sse.newEventBuilder()
    		  				.name("products")
                            .mediaType(MediaType.APPLICATION_JSON_TYPE)
                            .data(Product.class, prod)
                            .build();
                    sseEventSink.send(prodEvents);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
          });
    }
}
