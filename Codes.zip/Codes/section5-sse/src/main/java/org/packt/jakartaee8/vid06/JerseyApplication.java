package org.packt.jakartaee8.vid06;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("")
public class JerseyApplication extends Application { }
	    