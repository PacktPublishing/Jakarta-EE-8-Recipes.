package org.packt.jakartaee8.vid06;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.jms.Message;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.sse.OutboundSseEvent;
import javax.ws.rs.sse.Sse;
import javax.ws.rs.sse.SseBroadcaster;
import javax.ws.rs.sse.SseEventSink;

@Path("/broadcast")
@RequestScoped
public class SseBroadcastProdService {
	
	@Context
    private Sse sse;

	private volatile static SseBroadcaster sseBroadcaster;

    @PostConstruct
    public void postConstruct() {
       if (sseBroadcaster == null) {
            sseBroadcaster = sse.newBroadcaster();
        }
    }
    
    @GET
    @Path("/publish/{complaint}")
    public void broadcast(@PathParam("complaint") String complaint){
 	    OutboundSseEvent event = sse.newEventBuilder()
 			      .data(String.class, complaint)
 			      .reconnectDelay(6)
 			      .build();
 	   sseBroadcaster.broadcast(event);
 	}
 
	@GET
    @Path("/subscribe")
    @Produces(MediaType.SERVER_SENT_EVENTS)
    public void register(@Context SseEventSink eventSink){
		 eventSink.send(sse.newEventBuilder()
				 .data(String.class, "Can now start sending complaints: ")
				 .reconnectDelay(500).build());
		 sseBroadcaster.register(eventSink);
    }

    @POST
    @Path("/form/publish")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public void broadcastPost(@FormParam("complaint") String complaint){
 	    System.out.println(complaint);
    	OutboundSseEvent event = sse.newEventBuilder()
 			      .data(String.class, complaint)
 			      .reconnectDelay(6)
 			      .build();
 	   sseBroadcaster.broadcast(event);
 	}
     
     public void sendStreamCdiEvent(@Observes Message msg) {
     	sseBroadcaster.broadcast(
                 sse.newEventBuilder()
                         .mediaType(MediaType.TEXT_PLAIN_TYPE)
                         .name("review CDI events")
                         .data(msg)
                         .build()
         );
     }

}
