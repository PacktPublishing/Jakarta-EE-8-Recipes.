package org.packt.jakartaee8.vid07;

import java.util.Collections;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

import org.jnosql.diana.api.Settings;
import org.jnosql.diana.api.document.DocumentCollectionManagerAsync;
import org.jnosql.diana.api.document.DocumentCollectionManagerAsyncFactory;
import org.jnosql.diana.api.document.DocumentConfigurationAsync;
import org.jnosql.diana.mongodb.document.MongoDBDocumentConfiguration;

@ApplicationScoped
public class MongoDbInitializer{
	 
	  private DocumentConfigurationAsync configuration;
	  private DocumentCollectionManagerAsyncFactory managerFactory;
	  
	  private static final String COLLECTION = "product";

	  @PostConstruct
	  public void init() {
	    configuration = new MongoDBDocumentConfiguration();
	    Map<String, Object> settings = 
	      Collections.singletonMap("mongodb-server-host-1", "localhost:27017");
	    managerFactory = configuration.getAsync(Settings.of(settings));
	  }
	  
	  @Named(value="documentCollectionManager")
	  @Produces
	  public DocumentCollectionManagerAsync getManager() {
	    return managerFactory.getAsync(COLLECTION);
	  }
}
