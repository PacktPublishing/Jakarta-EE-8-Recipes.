package org.packt.jakartaee8.vid07;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.jnosql.artemis.document.DocumentTemplateAsync;
import org.jnosql.artemis.document.query.DocumentQueryMapperBuilder;
import org.jnosql.diana.api.document.DocumentQuery;

@Named(value="productDao")
@RequestScoped
public class ProductDaoImpl implements ProductDao {
	
	@Inject
	private DocumentTemplateAsync template;
	
	@Inject
	private DocumentQueryMapperBuilder mapperBuilder;

	@Override
	public void addProduct(Product prod){	
		template.insert(prod);
	}

	@Override
	public int deleteProduct(Product prod){
		template.delete(Product.class, prod.getId());
		return prod.getId();
	}

	@Override
	public int updateProduct(Product prod){
		template.update(prod);
		return prod.getId();
	}

	@Override
	public List<Product> listProducts() {
		DocumentQuery query = mapperBuilder.selectFrom(Product.class).build();
		List<Product> prods = new ArrayList<>();
		template.select(query, (pList)->{
			for(Object prod : pList) {
				Product temp = (Product) prod;
				System.out.println(temp.getName());
				prods.add(temp);
			}
		});
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) { }
		return prods;
	}
}
