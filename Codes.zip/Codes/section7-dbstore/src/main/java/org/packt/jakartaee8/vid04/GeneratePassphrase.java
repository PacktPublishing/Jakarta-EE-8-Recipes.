package org.packt.jakartaee8.vid04;

import java.util.HashMap;
import java.util.Map;

import javax.enterprise.context.RequestScoped;
import javax.security.enterprise.identitystore.Pbkdf2PasswordHash;

import org.glassfish.soteria.identitystores.hash.Pbkdf2PasswordHashImpl;

@RequestScoped
public class GeneratePassphrase {
	
	private static Pbkdf2PasswordHash passwordHash = new Pbkdf2PasswordHashImpl();
	
	public static void main(String args[]) {
		System.out.println(createHashCode("sjctrags"));
	}
	
	public static String createHashCode(String password) { 
		  Map<String, String> parameters = new HashMap<>();
	      parameters.put("Pbkdf2PasswordHash.Iterations", "3072");
	      parameters.put("Pbkdf2PasswordHash.Algorithm", "PBKDF2WithHmacSHA512");
	      parameters.put("Pbkdf2PasswordHash.SaltSizeBytes", "64");
	      passwordHash.initialize(parameters);
	        
        return passwordHash.generate(password.toCharArray());
    }

}
