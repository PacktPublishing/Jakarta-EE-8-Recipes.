package org.packt.jakartaee8.vid05;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Default;
import javax.inject.Named;
import javax.security.enterprise.identitystore.DatabaseIdentityStoreDefinition;
import javax.security.enterprise.identitystore.Pbkdf2PasswordHash;

@ApplicationScoped
@Default
@DatabaseIdentityStoreDefinition(
		
		dataSourceLookup = "${ dbConfig.jndiDbResource }",
	    callerQuery = "${ dbConfig.callQuery }",
	    groupsQuery = "${ dbConfig.groupsQuery }",
	    hashAlgorithm = Pbkdf2PasswordHash.class,
	    hashAlgorithmParameters = "${dbConfig.passphraseConfig}"
	)
@Named
public class DbConfig {
	
	public String getJndiDbResource() {
		return "java:comp/env/jdbc/jakartaEEDb";
	}
	
	public String getCallQuery() {
		return "select passphrase from user where username = ?";
	}
	
	public String getGroupsQuery() {
		return "select r.name as 'role'\r\n" + 
	    		"from permission p inner join role r inner join user u on\r\n" + 
	    		"p.roleId = r.id and p.userId = u.id and u.username like ?";
	}

	public String[] getPassphraseConfig() {
        return new String[]{
        		"Pbkdf2PasswordHash.Iterations=3072", 
        		"Pbkdf2PasswordHash.Algorithm=PBKDF2WithHmacSHA512",
        		"Pbkdf2PasswordHash.SaltSizeBytes=64"};
    }
}
