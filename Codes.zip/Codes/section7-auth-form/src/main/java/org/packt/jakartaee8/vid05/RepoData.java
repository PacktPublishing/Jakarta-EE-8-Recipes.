/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical service class.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid05;

import java.util.ArrayList;
import java.util.List;

public class RepoData {
	
	public List<Location> getLocData(){
		List<Location> locs = new ArrayList<>();
		Location locA = new Location();
		locA.setLocPost("A");
		locA.setLocName("China");
		locA.setRegionName("Asia");
		
		Location locB = new Location();
		locB.setLocPost("B");
		locB.setLocName("Zambia");
		locB.setRegionName("Africa");
		
		Location locC = new Location();
		locC.setLocPost("C");
		locC.setLocName("New York");
		locC.setRegionName("North America");
		
		locs.add(locA);
		locs.add(locB);
		locs.add(locC);
		return locs;
	}

}
