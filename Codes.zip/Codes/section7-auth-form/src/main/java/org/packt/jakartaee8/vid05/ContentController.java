/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the Login VIEW controller with POST HTTP service. 
 * 	It also highlights accessing parameters and scoped attributes.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid05;

import java.io.IOException;

import javax.annotation.security.DeclareRoles;
import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.ServletSecurity.TransportGuarantee;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/mycontent.html")
@DeclareRoles({"user", "administrator", "guest"})
@ServletSecurity(@HttpConstraint(rolesAllowed = {"administrator", "user"},
		    transportGuarantee=TransportGuarantee.NONE))
public class ContentController extends HttpServlet{
	
	@Inject
	private HttpSession session;
	
	@Inject
	private ServletContext context;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			req.setAttribute("userId", UserOp.generateUserId("1", "2"));	
			session.setAttribute("sessId", 101010);	
			context.setAttribute("locs", 
					new RepoData().getLocData());

		    req.getRequestDispatcher("/vid05/content.jsp").forward(req, resp);
	}
	
	
}
