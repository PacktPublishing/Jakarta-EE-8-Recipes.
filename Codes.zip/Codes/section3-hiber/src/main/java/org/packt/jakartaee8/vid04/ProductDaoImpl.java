package org.packt.jakartaee8.vid04;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.UserTransaction;

import org.hibernate.jpa.QueryHints;

import net.sf.ehcache.CacheManager;

@Named(value="productDao")
@RequestScoped
public class ProductDaoImpl implements ProductDao {
	
	@PersistenceContext(unitName="jakartaEEPU")
	private EntityManager em;
	 
	@Inject
	private UserTransaction utx;

	@Override
	public void addProduct(Product prod) {
		try {
			utx.begin();
			em.persist(prod);
			int size = CacheManager.ALL_CACHE_MANAGERS.get(0)
					  .getCache("org.packt.jakartaee8.vid04.Product").getSize();
			System.out.println("Cache size: " + size);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em.clear();
		}
	}

	@Override
	public int deleteProduct(Product prod){
		try {
			utx.begin();
			em.remove(prod);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em.clear();
		}
		
		return prod.getId();
	}

	@Override
	public int updateProduct(Product prod){
		try {
			utx.begin();
			em.merge(prod);
			utx.commit();
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			em.clear();
		}
		
		return prod.getId();
	}

	@Override
	public List<Product> listProducts() {
		//List<Product> prods = em.createQuery("SELECT p FROM Product p")
		//		.getResultList();
		Query query = em.createNamedQuery("inventory.listProds")
				.setHint("org.hibernate.cacheable", true);
		List<Product> prods = query.getResultList();
		
		return prods;
	}

	@Override
	public Product getProduct(int id) {
		Query query = em.createNamedQuery("inventory.getProd")
				.setHint("org.hibernate.cacheable", true);
		query.setParameter("id", id);
		Product p = (Product)query.getSingleResult();
		return p;
	}

	@Override
	public List<Double> unionMaxPrices(String name1, String name2) {
		List<Double> unionMaxPrices = em.createNamedQuery("unionMaxPrices")
				.setParameter("name1", name1)
				.setParameter("name2", name2)
				.getResultList();
		for(Object data : unionMaxPrices ) {
			System.out.println(data);
		}
		return unionMaxPrices;
	}


}
