/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the Login View controller with a highlight on
 *  injecting EJB session bean from local cache or remotely using InitialContext.
 *  Explains also the behavior of EJB session bean instantiation.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/prodview.html")
public class ProductResultView extends HttpServlet{
	
	private static final long serialVersionUID = -5529094220079458844L;

	@Named(value="productDao")
	@Inject
	private ProductDao productDao;
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Integer id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		Double price = Double.parseDouble(req.getParameter("price"));
		
		Product prod = new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		
		try {
			productDao.addProduct(prod);
		} catch (Exception e) {
			e.printStackTrace();
		}
		req.setAttribute("products", productDao.listProducts());
		req.setAttribute("unionMaxPrices", productDao.unionMaxPrices("%ike%", "567"));
		req.getRequestDispatcher("/vid04/prod_view.jsp").forward(req, resp);
	}

}
