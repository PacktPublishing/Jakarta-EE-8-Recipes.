/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical POJO when used in EJB session beans. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name="product")
@NamedQuery(name = "inventory.listProds", query = "SELECT p FROM Product p")
@NamedQuery(name = "inventory.getProd", query = "SELECT p FROM Product p WHERE p.id = :id")
@NamedNativeQuery(name= "unionMaxPrices", query = "select max(price) from product where name like :name1 " + 
		"UNION select max(price) from product where name = :name2")
@Cacheable(value=true)
@Cache(usage=CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Product implements Serializable{
		
    @Id
	private Integer id;
    
    @Column
	private String name;
    
    @Column
	private Double price;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

}
