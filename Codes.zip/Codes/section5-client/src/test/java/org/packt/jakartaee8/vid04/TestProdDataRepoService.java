package org.packt.jakartaee8.vid04;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.junit.Test;

public class TestProdDataRepoService {
	
	@Test
	public void testGetDataString() {
		
		Client client = ClientBuilder.newBuilder().build();
		WebTarget target = client.target("http://localhost:8080/sec5/repo/strdata");
		Invocation.Builder builder = target.request(MediaType.TEXT_PLAIN);
		Response resp = builder.get();
		System.out.println(resp.readEntity(String.class));
	}
	
	@Test
	public void testGetDataArray() {
		Client client = ClientBuilder.newBuilder().build();
		String[] arrdata = client.target("http://localhost:8080/sec5/repo/arrdata")
				.request(MediaType.APPLICATION_JSON)
				.get(String[].class);
		for(String str : arrdata) {
			System.out.println(str);
		}
	}
	
	@Test
	public void testGetDataCollection() {
		Client client = ClientBuilder.newBuilder().build();
		List<String> listdata = client.target("http://localhost:8080/sec5/repo/listdata")
				.request(MediaType.APPLICATION_JSON)
				.get(new GenericType<List<String>>() {});
		for(String str : listdata) {
			System.out.println(str);
		}
	}
	
	@Test
	public void testGetDataEntity() {
		Client client = ClientBuilder.newBuilder().build();
		Product prod = client.target("http://localhost:8080/sec5/repo/product")
				.request(MediaType.APPLICATION_JSON)
				.get(Product.class);
		System.out.println(prod.getName());
	}

}
