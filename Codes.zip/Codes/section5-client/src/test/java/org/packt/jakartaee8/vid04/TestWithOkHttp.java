package org.packt.jakartaee8.vid04;

import java.io.IOException;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.junit.Test;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class TestWithOkHttp {
	
	@Test
    public void testReactOkHttp() {
    	
    	Request request = new Request.Builder()
    	        .url("https://localhost:8443/sec5/async/product/list")
    	        .build();
    	OkHttpClient client = new OkHttpClient();
    	Response response;
		try {
			response = client.newBuilder()
					.hostnameVerifier(new HostnameVerifier() {
						@Override
						public boolean verify(String hostname, SSLSession session) {
							return true;
						}
					})
					.followRedirects(true)
					.retryOnConnectionFailure(true)
					.build().newCall(request).execute();
			
			System.out.println(response.body().string());
		} catch (IOException e) {
			e.printStackTrace();
		}
	
    	
    	
    }
    
    @Test
    public void testTestPatch() {
    	Product prod = new Product();
    	prod.setName("Gems");
				
		Jsonb jsonb = JsonbBuilder.create();
		String json = jsonb.toJson(prod);
		
		RequestBody body = RequestBody.create(okhttp3.MediaType.parse("application/json"), json );
    	Request request = new Request.Builder()
    	        .url("https://localhost:8443/sec5/dao/product/filter/patch/10")
    	        .patch(body)
    	        .build();
    	OkHttpClient client = new OkHttpClient();
    	Response response;
		try {
			response = client.newBuilder().hostnameVerifier(new HostnameVerifier() {
		        @Override
		        public boolean verify(String hostname, SSLSession session) {
		            return true;
		        }
		    }).followRedirects(true).retryOnConnectionFailure(true).build().newCall(request).execute();
			System.out.println(response.body().string());
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
	

}
