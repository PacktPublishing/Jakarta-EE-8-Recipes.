package org.packt.jakartaee8.vid04;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.Test;

public class TestProdJsonDaoService {
	
	@Test
	public void testGetProduct() {
		Client client = ClientBuilder.newBuilder().
				register(JacksonJaxbJsonProvider.class).build();
		String prods = client.target("http://localhost:8080/sec5/json/product/filter/10")
				.request(MediaType.APPLICATION_JSON)
				.get(String.class);
		System.out.println(prods);
	 }
    
    @Test
	public void testGetJsonProductArray() {
		Client client = ClientBuilder.newBuilder().register(JacksonJaxbJsonProvider.class).build();
		String prods = client.target("http://localhost:8080/sec5/json/product/list")
				.request(MediaType.APPLICATION_JSON)
				.get(String.class);
		System.out.println(prods);
	 }

}
