package org.packt.jakartaee8.vid04;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.HttpUrlConnectorProvider;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.Test;

public class TestProdDaoService {
	
	@Test
	public void testListProduct() {
		Client client = ClientBuilder.newBuilder()
				.register(JacksonJaxbJsonProvider.class).build();
		List<Product> prods = client.target("http://localhost:8080/sec5/dao/product/list")
				.request(MediaType.APPLICATION_JSON)
				.get(new GenericType<List<Product>>() {});
		prods.stream().forEach((p)->{
			System.out.format("%d %s %.4f\n", p.getId(), p.getName(), p.getPrice());
		});
	 }
	 
	 @Test
	 public void testAddProduct() {
    	Product p = new Product();
	    p.setId(456900);
	    p.setName("Corn");
	    p.setPrice(67898.90);
	    	
	    Client client = ClientBuilder.newBuilder()
	    		.register(JacksonJaxbJsonProvider.class).build();
		Product response = client.target("http://localhost:8080/sec5/dao/product/addjson")
			.request(MediaType.APPLICATION_JSON)
			.accept(MediaType.APPLICATION_JSON)
			.post(Entity.entity(p, MediaType.APPLICATION_JSON), Product.class);
		System.out.println(response.getName());	
	   }
	 
	 @Test
	 public void testUpdateProduct() {
		 Product p = new Product();
		 p.setId(1021);
		 p.setName("Hershey's Choco");
		 p.setPrice(67898.90);
    	
	    Client client = ClientBuilder.newBuilder()
	    		.register(JacksonJaxbJsonProvider.class).build();
		Product response = client.target("http://localhost:8080/sec5/dao/product/update")
			.request(MediaType.APPLICATION_JSON)
			.accept(MediaType.APPLICATION_JSON)
			.put(Entity.entity(p, MediaType.APPLICATION_JSON), 
					Product.class);
		System.out.println(response.getName());	
	   }
	 
	 @Test
	 public void testDeleteProduct() {
	    Client client = ClientBuilder.newBuilder()
	    		.register(JacksonJaxbJsonProvider.class).build();
		Product response = client.target("http://localhost:8080/sec5/dao/product/remove/10333")
			.request(MediaType.APPLICATION_JSON)
			.delete(Product.class);
		System.out.println(response.getName());	
	  }
	 
	 
	 @Test
	 public void testFilterPatch() {
	 	Product prod = new Product();
		prod.setName("Corn Powder");
			
		Client client = ClientBuilder.newBuilder()
				.register(JacksonJaxbJsonProvider.class).build();
			
	    Response response = client
			.target("http://localhost:8080/sec5/dao/product/filter/patch/10")
			.request(MediaType.APPLICATION_JSON)
			.build("PATCH", Entity.entity(prod, MediaType.APPLICATION_JSON))
			.property(HttpUrlConnectorProvider.SET_METHOD_WORKAROUND, true)
			.invoke();
		System.out.println(response.readEntity(Product.class).getName());
	  }
	    
}
