package org.packt.jakartaee8.vid04;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.junit.Test;

public class TestClientBuilderHttp2 {
	
	@Test
	public void testListProduct() {
		Client client = ClientBuilder.newBuilder()
				.hostnameVerifier(generateHostVerifier())
				.sslContext(createSSLContext())
				.register(JacksonJaxbJsonProvider.class).build();
		List<Product> prods = client.target("https://localhost:8443/sec5/dao/product/list")
				.request(MediaType.APPLICATION_JSON)
				.get(new GenericType<List<Product>>() {});
		prods.stream().forEach((p)->{
			System.out.format("%d %s %.4f\n", p.getId(), p.getName(), p.getPrice());
		});
	 }
	
	 private SSLContext createSSLContext() {
	        SSLContext sslContext = null;
	        try {
	        	sslContext = SSLContext.getInstance("TLS");
	          	sslContext.init(null,
	                    new X509TrustManager[] { new X509TrustManager() {
	                        @Override
	                        public void checkClientTrusted(X509Certificate[] chain,String authType) throws CertificateException {}
	                        @Override
	                        public void checkServerTrusted(X509Certificate[] chain,String authType) throws CertificateException {}
	                        @Override
	                        public X509Certificate[] getAcceptedIssuers() {return null;}
	                    } }, null);
	               } catch (NoSuchAlgorithmException e) {
	            e.printStackTrace();
	        } catch (KeyManagementException e) {
	            e.printStackTrace();
	        } 
	        return sslContext;
	    }

	    private HostnameVerifier generateHostVerifier() {
	        return new HostnameVerifier() {
	            @Override
	            public boolean verify(String hostname, SSLSession session) 
	            {return true;}
	        };
	    }

}
