package org.packt.jakartaee8.vid04;

import java.net.URI;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.junit.Before;
import org.junit.Test;

import jdk.incubator.http.HttpClient;
import jdk.incubator.http.HttpRequest;
import jdk.incubator.http.HttpRequest.BodyPublisher;
import jdk.incubator.http.HttpResponse;
import jdk.incubator.http.HttpResponse.BodyHandler;

public class TestWithHttpClient {
	
	private HttpClient client = null;
	
	@Before
	public void setup() {
		client = HttpClient.newHttpClient();
	}
	
	@Test
	public void testHttpClientGet() {
		Path file = Paths.get("./src/main/java/products.json");
				
		CompletableFuture<HttpResponse<Path>> getClientSaveFile = 
				client.sendAsync(HttpRequest.newBuilder()
	    		       .uri(URI.create("https://localhost:8443/sec5/async/product/list"))
	    		       .GET()
                       .build(), BodyHandler.asFile(file));
		
		try {
			HttpResponse resp = getClientSaveFile.get();
			System.out.println(resp.body());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		getClientSaveFile.thenAccept(nioResponse -> {
			System.out.println(nioResponse.statusCode());
			System.out.println("done JSON file copy...");
	    });
	    */
	    
	}
	
	@Test
	public void testHttpClientPost() {
		HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create("https://localhost:8443/sec5/dao/product/list"))
	            .POST(BodyPublisher.noBody())
	            .build();
		
		CompletableFuture<HttpResponse<String>> 
		       getClientResp = client.sendAsync(request, BodyHandler.asString());
		try {
			String jsonData = getClientResp.get(1000, TimeUnit.SECONDS).body();
			System.out.println(jsonData);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (TimeoutException e) {
			e.printStackTrace();
		}
		/*
		getClientResp.thenAccept(nioResponse -> {
		      System.out.println(nioResponse.statusCode());
		      System.out.println(nioResponse.body());
		      
		  });
		  */
	}

}
