package org.packt.jakartaee8.vid04;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.rx.guava.RxListenableFutureInvoker;
import org.glassfish.jersey.client.rx.guava.RxListenableFutureInvokerProvider;
import org.glassfish.jersey.client.rx.rxjava.RxObservableInvoker;
import org.glassfish.jersey.client.rx.rxjava.RxObservableInvokerProvider;
import org.glassfish.jersey.client.rx.rxjava2.RxFlowableInvoker;
import org.glassfish.jersey.client.rx.rxjava2.RxFlowableInvokerProvider;
import org.junit.Test;

import com.google.common.util.concurrent.ListenableFuture;

public class TestAsyncProdDaoService {
	
	 @Test
	 public void testListProductAsyncClient() {
		 
		 ExecutorService pool = Executors.newFixedThreadPool(2);
		 Client client = ClientBuilder.newBuilder()
				 .connectTimeout(1000, TimeUnit.SECONDS)
				 .readTimeout(500, TimeUnit.SECONDS)
			     .executorService(pool).build();
		 Future<List<Product>> prods = 
					client.target("http://localhost:8080/sec5/async/product/list")
					.request(MediaType.APPLICATION_JSON)
					.async()
					.get(new GenericType<List<Product>>() {});
		            // enable below if in non-blocking mode
					/*
					.get(new InvocationCallback<List<Product>>() {

						@Override
						public void completed(List<Product> response) {
							// TODO Auto-generated method stub
							
						}

						@Override
						public void failed(Throwable throwable) {
							// TODO Auto-generated method stub
							
						}
						
					});
					*/
		 try {
			prods.get().stream().forEach((p)->{
				System.out.format("%d %s %.4f\n", p.getId(), p.getName(), p.getPrice());
			});
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	 }
	 
	 @Test
	 public void testListProductRxClient() {
		 WebTarget target = ClientBuilder.newBuilder()
				 .connectTimeout(1000, TimeUnit.SECONDS)
				 .readTimeout(500, TimeUnit.SECONDS)
				 .build()
				 .target("http://localhost:8080/sec5/async/product/list");

	        CompletableFuture<List<Product>> prodCf =target.request()
	                .rx()
	                .get(new GenericType<List<Product>>() {})
	                .toCompletableFuture();
	        	       
	        try {
				System.out.println(prodCf.get());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
			
	 }
	 
	 @Test
	    public void testListProductObxClient() {
	    	Client client = ClientBuilder.newBuilder()
	    			.connectTimeout(1000, TimeUnit.SECONDS)
					.readTimeout(500, TimeUnit.SECONDS)
					.register(RxObservableInvokerProvider.class)
	    			.build();
	        
	        WebTarget target = 
	        		client.target("http://localhost:8080/sec5/async/product/list");

	        List<Product> prods = target.request()
	                .rx(RxObservableInvoker.class)
	                .get(new GenericType<List<Product>>() {})
	                .toBlocking().first();
	        System.out.println(prods);
	    }
	    
	    @Test
	    public void testListProductFlowClient() {
	    	Client client = ClientBuilder.newBuilder()
	    			.connectTimeout(1000, TimeUnit.SECONDS)
					.readTimeout(500, TimeUnit.SECONDS)
					.register(RxFlowableInvokerProvider.class)
	    			.build();

	        WebTarget target = client.target("http://localhost:8080/sec5/async/product/list");

	        List<Product> prods = target.request()
	                .rx(RxFlowableInvoker.class)
	                .get(new GenericType<List<Product>>() {})
	                .blockingSingle();
	        System.out.println(prods);
	    }
	    
	    @Test
	    public void testListProductGuavaClient() {
	    	Client client = ClientBuilder.newBuilder()
	    			.connectTimeout(1000, TimeUnit.SECONDS)
					.readTimeout(500, TimeUnit.SECONDS)
					.register(RxListenableFutureInvokerProvider.class)
	    			.build();

	        WebTarget target = client.target("http://localhost:8080/sec5/async/product/list");

	        ListenableFuture<List<Product>> prods;
			try {
				prods = target.request()
				        .rx(RxListenableFutureInvoker.class)
				        .get(new GenericType<List<Product>>() {});
				        
				prods.get().stream().forEach((p)->{
					System.out.format("%d %s %.4f\n", p.getId(), p.getName(), p.getPrice());
				});
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
	       
	    }


	 

}
