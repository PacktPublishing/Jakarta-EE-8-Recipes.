// create and enable this if you really want to use HttpClient
module org.packt.jakartaee8.vid04 {   
 requires jdk.incubator.httpclient;
}