package org.packt.jakartaee8.vid02;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Default;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.IdentityStore;

@Default
@ApplicationScoped
public class ContentExclusiveIdentityStore implements IdentityStore {
	
	private Map<String, String> exclusive;
		
	@PostConstruct
	public void init() {
		exclusive = new HashMap<>();
		exclusive.put("guest", "guest");
		exclusive.put("root", "root");
		exclusive.put("manager", "manager");
	}
	
    public CredentialValidationResult validate(UsernamePasswordCredential usernamePasswordCredential) {
    	 System.out.println("ContentExclusiveIdentityStore invoked...");
    	 String caller = usernamePasswordCredential.getCaller();
    	 if(exclusive.containsKey(caller)  ) {
    		  return new CredentialValidationResult(caller, new HashSet<String>(Arrays.asList("administrator", "user")));
    		 
    	 }
    
        return CredentialValidationResult.INVALID_RESULT;
    }
    
    @Override
    public int priority() {
    	return 50;
    }

}
