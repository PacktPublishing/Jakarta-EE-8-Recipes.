/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements generating non-HTML content using ServletOutputStream. 
 * 	It also highlights Java Stream API and HTTP response headers.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid02;

import java.io.IOException;
import java.util.function.Function;

import javax.annotation.security.DeclareRoles;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/mycontentDoc")
@DeclareRoles({"user", "administrator", "guest"})
@ServletSecurity(@HttpConstraint(rolesAllowed = {"user"}))
@BasicAuthenticationMechanismDefinition(realmName="Packt-Basic-2" )
public class ContentDocController extends HttpServlet{
		
   	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
    	  resp.setContentType("application/msword;charset=UTF-8");
    	  resp.setHeader("content-disposition",
    			  "attachment;filename=locations.doc");
    	  
    	  RepoData locData = new RepoData();
    	  
    	  Function<Location, String> mapLocToString = (loc)->{
    		  return loc.getLocPost() + " " + loc.getLocName() + " " + loc.getRegionName() + '\n';
    	  };
    	  
    	  String dataString = locData.getLocData()
    			  .stream()
    			  .map(mapLocToString)
    			  .reduce("", (a,b) -> a + b);

          ServletOutputStream out = resp.getOutputStream();
  		  out.println(dataString);
    }
}
