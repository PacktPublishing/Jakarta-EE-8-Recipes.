/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements a default bean class. 
 * 	It also highlights how scoped beans interacts with external injections using Project Lombok.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Default;
import javax.inject.Named;

import lombok.Getter;

@Named
@Default
@RequestScoped
public class RandomUserIDBuilder implements UserIDBuilder{
	
	@Getter
	private Date today;
		
	@PostConstruct
	public void initDate() {
		today = new Date();
	}

	@Override
	public String transformUserId(String username, String password) {
		return String.join("", "USER-", username.charAt(0)+"", password.charAt(0)+"").toUpperCase();
	}

}
