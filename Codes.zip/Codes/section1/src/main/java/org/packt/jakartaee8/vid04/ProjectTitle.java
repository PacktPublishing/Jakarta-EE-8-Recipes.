/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements application scoped beans using CDI 2.0. 
 * 	It defines a custom qualifier name for the bean.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

@Named(value="projTitle")
@ApplicationScoped
public class ProjectTitle {
	
	public String createTitle() {
		return "JAKARTA EE 8";
	}

}
