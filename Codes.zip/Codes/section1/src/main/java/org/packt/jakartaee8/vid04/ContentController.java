/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the main controller of the application
 *  with a POST HTTP service. 
 * 	It also uses CDI 2.0 in auto-wiring or injecting bean objects, resources, 
 *  and simple container events.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/mycontent3.html")
public class ContentController extends HttpServlet{
	
	@Inject
	private UserIDBuilder userIDBuilder;
	
	@Inject
	private Lookup lookup;
	
	@Inject
	private HttpSession session;
	
	@Inject
	private ServletContext context;
	
	@Inject
	private LocationStatus locationStatus;
	
	@Inject
	private RepoData repoData;
	
	private RepoDataTxn repoDataTxn;
	
	@Inject
	@Named("regions")
	private List<String> regions;
	
	@Inject
	@Named("statuses")
	private List<String> statuses;
	
	@Inject
	public ContentController(@Named("repotxn") RepoDataTxn repoDataTxn) {
		this.repoDataTxn = repoDataTxn;
	}
	
	private static final long serialVersionUID = -2278150316207189899L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// HttpSession session = req.getSession(true);
		String username = req.getParameter("username");
		String password = req.getParameter("password");
				
		req.setAttribute("userId", UserOp.generateUserId(username, password));
		
		req.setAttribute("base_status", locationStatus.evalStatus(600));
		
		req.setAttribute("final_status", 
				repoDataTxn.getActualSizeStatus(repoData.getLocData()));
		
		req.setAttribute("title", lookup.getTitle());
				
		req.setAttribute("num_status", statuses.size());
		req.setAttribute("num_region", regions.size());
		
		req.setAttribute("userId", userIDBuilder.transformUserId(username, password));
		
		req.getRequestDispatcher("/vid04/content.jsp").forward(req, resp);
	}
}
