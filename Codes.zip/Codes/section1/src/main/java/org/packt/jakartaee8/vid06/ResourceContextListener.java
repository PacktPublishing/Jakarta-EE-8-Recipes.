/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements listener for global context events. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.inject.Inject;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/* Uncomment the annotation below to enable listener. */
//@WebListener
public class ResourceContextListener implements ServletContextListener{
	
	@Inject
	private DataResource dataResource;
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		sce.getServletContext().setAttribute("products", 
				dataResource.getProducts());
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		dataResource = null;
	}

}
