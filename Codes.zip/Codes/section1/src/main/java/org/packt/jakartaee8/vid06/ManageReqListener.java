/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements listener every request dispatch process. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

//Uncomment the annotation below to enable listener. */
//@WebListener
public class ManageReqListener implements ServletRequestListener{
	
	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		System.out.println("REQUEST CLOSED: " + 
	              sre.getServletRequest().getDispatcherType().name());
	}
	
	@Override
	public void requestInitialized(ServletRequestEvent sre) {
		System.out.println("REQUEST OPENED: " + 
	              sre.getServletRequest().getDispatcherType().name());
		sre.getServletRequest().getParameterNames()
		            .asIterator()
		            .forEachRemaining((param)->{
		            	System.out.println(param);
		            });
	}

}
