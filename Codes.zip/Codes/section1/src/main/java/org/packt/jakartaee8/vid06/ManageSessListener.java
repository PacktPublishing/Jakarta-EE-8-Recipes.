/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements listener every session-related transaction. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/* Uncomment the annotation below to enable listener. */
//@WebListener
public class ManageSessListener implements HttpSessionListener{
	
	private long num_session = 0;
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		se.getSession().setAttribute("session_count", num_session);
		System.out.println("Session Created ID ="+se.getSession().getId());
		
	}
	
	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		long count = (long) se.getSession().getAttribute("session_count");
		if(count >= 0) {
			count++;
			se.getSession().setAttribute("session_count", num_session);
		}
		System.out.println("Session Destroyed ID ="+se.getSession().getId());
	}

}
