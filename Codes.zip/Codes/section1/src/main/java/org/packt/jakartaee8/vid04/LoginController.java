/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the Login Form controller with multiple responses using PushBuilder. 
 * 	It also pushes web resources such as JS, CSS, PNG, and even HTML content
 *  into the browser cache for page loading performance.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/mylogin3.html")
public class LoginController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Optional.ofNullable(req.newPushBuilder())
		.ifPresent(pb ->{
				pb.path("js/jquery.min.js")
                   .addHeader("content-type", "application/javascript")
                   .push();
		});
		
		Optional.ofNullable(req.newPushBuilder())
				.ifPresent(pb ->{
						pb.path("js/bootstrap.min.js")
							.addHeader("content-type", "application/javascript")
							.push();
		});
		
		Optional.ofNullable(req.newPushBuilder())
		.ifPresent(pb ->{
				pb.path("js/npm.js")
					.addHeader("content-type", "application/javascript")
					.push();
		});
		
		Optional.ofNullable(req.newPushBuilder())
				.ifPresent(pb ->{
						pb.path("css/bootstrap.min.css")
							.addHeader("content-type", "text/css")
							.push();
		});
		
		 Optional.ofNullable(req.newPushBuilder())
		 		.ifPresent(pb ->{
		 				pb.path("images/login_user.png")
		 					.addHeader("content-type", "image/png")
		 					.push();
         });
		 
		 
		 Optional.ofNullable(req.newPushBuilder())
	 		.ifPresent(pb ->{
	 				pb.path("/sec1/mycontent3.html")
	 					.addHeader("content-type", "text/html")
	 					.push();
	 		});
		
				
		req.getRequestDispatcher("/vid04/login.jsp").forward(req, resp);
	}

}
