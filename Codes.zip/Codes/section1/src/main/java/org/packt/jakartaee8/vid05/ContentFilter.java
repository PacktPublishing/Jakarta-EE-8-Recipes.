/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements filter using GenericFilter. 
 * 	It also highlights some its methods like accessing FilterConfig.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid05;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.GenericFilter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

@WebFilter(urlPatterns="/mycontent3.html", 
           filterName="ContentFilter", 
           initParams= {@WebInitParam(name="filter_id", value="10101")})
public class ContentFilter extends GenericFilter{
	
	private static final long serialVersionUID = -5998170396649169356L;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		request.setAttribute("bgcolor", "background-color:black; color:white; padding:20px;");
		//System.out.println(getFilterConfig().getFilterName());
		//System.out.println(getFilterConfig().getInitParameter("filter_id"));
		
		chain.doFilter(request, response);
		
	}
	
	 
	
	

}
