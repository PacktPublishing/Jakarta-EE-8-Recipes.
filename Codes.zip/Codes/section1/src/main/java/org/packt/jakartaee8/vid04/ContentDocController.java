/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements generating non-HTML content using ServletOutputStream. 
 * 	It also highlights CDI 2.0 constructor injection of request scoped objects.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.IOException;
import java.util.function.Function;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/contentDoc2")
public class ContentDocController extends HttpServlet{
	
	private RepoData repoData;
	private RepoDataTxn repoDataTxn;
			
	@Inject
	public ContentDocController(RepoData repoData, 
			  @Named("repotxn") RepoDataTxn repoDataTxn) {
		this.repoData = repoData;
		this.repoDataTxn = repoDataTxn;
	}
		
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	
    	  resp.setContentType("application/msword;charset=UTF-8");
    	  resp.setHeader("content-disposition", "attachment;filename=locations.doc");
    	  
    	  Function<Location, String> mapLocToString = (loc)->{
    		  return loc.getLocPost() + " " + loc.getLocName() + " " + loc.getRegionName() + '\n';
    	  };
    	  
    	  String dataString = repoDataTxn.sortLocByName(repoData.getLocData())
    			  .stream()
    			  .map(mapLocToString)
    			  .reduce("", (a,b) -> a + b);

          ServletOutputStream out = resp.getOutputStream();
  		  out.println(dataString);
    }
}
