/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements request scoped beans using CDI 2.0. 
 * 	It generates default qualifier names for beans.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class LocationStatus {
	
	public String evalStatus(int locSize) {
		
		if(locSize >= 1000) {
			return "very stable";
		}else if(locSize >= 500) {
			return "stable";
		}else {
			return "unstable";
		}
	}

}
