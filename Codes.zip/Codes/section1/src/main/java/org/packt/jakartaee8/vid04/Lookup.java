/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements producer methods using CDI 2.0. 
 * 	It also highlights creating dependent beans with CDI 2.0 method producers.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

@Named
@Dependent
public class Lookup {
	
	public String getTitle() {
		return "CDI 2.0";
	}
	
	@Named("regions")
	@Produces
	public List<String> listRegions(){
		String criteria[] = {"ASIA", "AFRICA", "NORTH AMERICA", "SOUTH AMERICA", "EAST EUROPE"};
		return Arrays.asList(criteria);
	}
	
	@Named("statuses")
	@Produces
	public List<String> listStatuses(){
		String criteria[] = {"VERY STABLE", "STABLE", "UNSTABLE"};
		return Arrays.asList(criteria);
	}
	
	

}
