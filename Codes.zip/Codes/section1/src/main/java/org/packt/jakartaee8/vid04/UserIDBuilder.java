/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This interface is the blueprint of the default and alternative bean objects.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */
package org.packt.jakartaee8.vid04;

public interface UserIDBuilder {
	
	public String transformUserId(String username, String password);

}
