/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class shows how to implement the class HttpServletMapping and use it for URL mapping. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.MappingMatch;

@WebServlet(urlPatterns= {"/", "/navb", "/navc/*", "*.jsp"}, name="MainController")
public class MainController extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		  HttpServletMapping Urlmapping = req.getHttpServletMapping();
	 
	      MappingMatch mappingMatch = Urlmapping.getMappingMatch();
	      System.out.println("Mapping Match: " + mappingMatch);
	      System.out.println("Match Value: " + Urlmapping.getMatchValue());
	      System.out.println("Pattern: " + Urlmapping.getPattern());
	      System.out.println("Servlet Name: " + Urlmapping.getServletName());
	      
	      switch(Urlmapping.getPattern()) {
	      	case "/navb":
	      		req.getRequestDispatcher("/path2").forward(req, resp);
	      		break;
	      	case "/navc/*":
	      		req.getRequestDispatcher("/path3/*").include(req, resp);
	      		break;
	      	case "*.jsp":
	      		req.getRequestDispatcher("/path4.jsp").forward(req, resp);
	      		break;	  
	      	case "/":
	      		System.out.println("no response page");
	      		break;
	      }
	      
	      
	}

}
