/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements how request scoped beans injects other request scoped attributes. 
 * 	It also highlights method injection using CDI 2.0.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("repotxn")
@RequestScoped
public class RepoDataTxn {
	
	private LocationStatus locStatus;
	
	public List<Location> sortLocByName(List<Location> locs) {
		return locs.stream().sorted((loc1, loc2) -> loc1.getLocName()
				.compareTo(loc2.getLocName()))
				.collect(Collectors.toList());
	}
	
	public List<Location> filterByRegion(List<Location> locs, String regionName) {
		return locs.stream()
				.filter((loc) -> loc.getRegionName().equalsIgnoreCase(regionName))
				.collect(Collectors.toList());
	}

	@Inject
	public void setLocStatus(LocationStatus locationStatus) {
		this.locStatus = locationStatus;
	}
	
	public String getActualSizeStatus(List<Location> locs) {
		return locStatus.evalStatus(locs.size());
	}
}
