/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements application scoped beans using CDI 2.0. 
 * 	It generates a default qualifier name for the bean.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

@Named
@ApplicationScoped
public class RepoData {
	
	public List<Location> getLocData(){
		List<Location> locs = new ArrayList<>();
		Location locA = new Location();
		locA.setLocPost("A");
		locA.setLocName("China");
		locA.setRegionName("Asia");
		Location locB = new Location();
		locB.setLocPost("B");
		locB.setLocName("Zambia");
		locB.setRegionName("Africa");
		Location locC = new Location();
		locC.setLocPost("C");
		locC.setLocName("New York");
		locC.setRegionName("North America");
		
		locs.add(locA);
		locs.add(locB);
		locs.add(locC);
		return locs;
	}

}
