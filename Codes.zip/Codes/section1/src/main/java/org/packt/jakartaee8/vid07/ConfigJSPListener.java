/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class highlights the use of addJspFile() method of ServlerContext. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid07;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class ConfigJSPListener implements ServletContextListener{
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {	}
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		sce.getServletContext()
		    .addJspFile("ErrorLoginView", "/vid07/error_login.jsp");
	}
}
