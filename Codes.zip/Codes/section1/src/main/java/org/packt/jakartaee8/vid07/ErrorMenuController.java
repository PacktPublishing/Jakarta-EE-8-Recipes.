/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class accesses the Servet mapped to a JSP by addJspFile() of ServletContext. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid07;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/errors.html")
public class ErrorMenuController extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getServletContext()
		     .getNamedDispatcher("ErrorLoginView").include(req, resp);
	}
}
