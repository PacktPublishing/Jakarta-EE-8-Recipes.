/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements listener for all events on request attributes. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.annotation.WebListener;

/* Uncomment the annotation below to enable listener. */
//@WebListener
public class ManageContentAttsListener 
            implements ServletRequestAttributeListener{
	
	public void attributeAdded(ServletRequestAttributeEvent event){
        System.out.println("Attribute Added: "+ event.getName()+ " = "+ event.getValue()+ "  added to request");
    }
 
    public void attributeReplaced(ServletRequestAttributeEvent event){
       System.out.println("Attribute Replaced: "+ event.getName()+ " = "+ event.getValue()+ "  updated");
    }
    
    public void attributeRemoved(ServletRequestAttributeEvent event){
       System.out.println("Attribute Removed: "+ event.getName()+ " = "+ event.getValue()+ "  removed from request");
    } 

}
