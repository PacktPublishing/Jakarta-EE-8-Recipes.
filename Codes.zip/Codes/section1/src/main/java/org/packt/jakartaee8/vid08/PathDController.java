/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class shows how HttpServletMapping responds to getRequestDispatch() process. 
 * 	 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid08;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.MappingMatch;

@WebServlet(urlPatterns= {"/path4", "/path4/*", "/path4.jsp"}, name="PathDController")
public class PathDController extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		  HttpServletMapping httpServletMapping = req.getHttpServletMapping();
		  PrintWriter out = resp.getWriter();
	 
	      MappingMatch mappingMatch = httpServletMapping.getMappingMatch();
	 
	      System.out.println("Mapping Match: " + mappingMatch);
	      System.out.println("Match Value: " + httpServletMapping.getMatchValue());
	      System.out.println("Pattern: " + httpServletMapping.getPattern());
	      System.out.println("Servlet Name: " + httpServletMapping.getServletName());
	      
	      out.println("PATH D");
	      
	}

}
