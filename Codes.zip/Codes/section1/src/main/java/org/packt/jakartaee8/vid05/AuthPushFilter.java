/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements filter using HttpFilter. 
 * 	It also highlights creating multiple responses using PushBuilder.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid05;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter("/mycontent3.html")
public class AuthPushFilter extends HttpFilter{
	
	private static final long serialVersionUID = -7824876826498014909L;

	@Override
	public void init(FilterConfig config) throws ServletException { }
	
	@Override
	protected void doFilter(HttpServletRequest req, 
			      HttpServletResponse res, FilterChain chain)
			        throws IOException, ServletException {
		
		String username = req.getParameter("username");
		String password = req.getParameter("password");
	
		if(!(username.equalsIgnoreCase("admin") && 
				password.equalsIgnoreCase("admin"))) {
		  res.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
		  res.setHeader("Location", "/sec1/vid05/invalid_user.jsp");
		}
		
		Optional.ofNullable(req.newPushBuilder())
	 	  .ifPresent(pb ->{
	 				pb.path("/sec1/mylogin3.html")
	 					.addHeader("content-type", "text/html")
	 					.push();
	 	});
		
		chain.doFilter(req, res);
	}
	
	@Override
	public void destroy() { }

}
