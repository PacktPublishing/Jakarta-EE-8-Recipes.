/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements session scoped beans using CDI 2.0. 
 * 	It generates a default qualifier name for bean.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class SessionId implements Serializable{
	
	private Integer sessionId;
	
	@PostConstruct
	public void init() {
		sessionId = (int)(Math.random()*10000);
	}
	
	public Integer getSessId() {
		return sessionId;
	}

}
