/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements a request scoped CDI 2.0 bean that is an alternative
 *  to the default bean object. 
 * 	It also highlights method injection using CDI 2.0.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Priority;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Alternative;
import javax.inject.Named;

import lombok.Getter;

@Named
@Alternative
@Priority(500)
@RequestScoped
public class ReverseUserIDBuilder implements UserIDBuilder {
	
	@Getter
	private Date today;
	
	@PostConstruct
	public void initDate() {
		today = new Date();
	}

	@Override
	public String transformUserId(String username, String password) {
		StringBuilder userId = new StringBuilder(username.concat(password));
		return userId.reverse().toString();
	}

}
