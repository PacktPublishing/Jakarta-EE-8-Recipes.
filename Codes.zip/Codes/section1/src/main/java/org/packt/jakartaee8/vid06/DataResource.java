/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical CDI 2.0 application scoped bean.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 3, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

import java.util.HashMap;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

@Named
@ApplicationScoped
public class DataResource {
	
	public Map<String, Double> getProducts(){
		Map<String,Double> products;
		products = new HashMap<>();
		products.put("mango", 2000.00);
		products.put("apple", 3000.00);
		products.put("lemon", 6000.00);
		return products;
	}

}
