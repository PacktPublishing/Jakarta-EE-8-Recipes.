/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This request-scoped injectable class uses a container event to initialize an object.
 * 	It also highlights how scoped beans interacts with external injections using Project Lombok.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import lombok.Getter;

@Named
@RequestScoped
public class DateLombokOp {
	
	@Getter
	private Date today;
		
	@PostConstruct
	public void initDate() {
		today = new Date();
	}

}
