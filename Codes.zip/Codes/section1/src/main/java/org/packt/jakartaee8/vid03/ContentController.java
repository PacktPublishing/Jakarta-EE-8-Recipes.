/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This class implements the Login VIEW controller with POST HTTP service. 
 * 	It also highlights accessing parameters and scoped attributes.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/mycontent2.html")
public class ContentController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(true);
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		
		req.setAttribute("userId", UserOp.generateUserId(username, password));
		
		session.setAttribute("sessId", 101010);
		
		req.getServletContext().setAttribute("locs", 
				new RepoData().getLocData());
		
		req.getRequestDispatcher("/vid03/content.jsp").forward(req, resp);
	}
}
