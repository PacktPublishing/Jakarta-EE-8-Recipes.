package org.packt.jakartaee8.vid03;

import java.io.IOException;

import javax.annotation.security.DeclareRoles;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpMethodConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.ServletSecurity.EmptyRoleSemantic;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/myget.html")
@DeclareRoles({"user", "administrator"})
@ServletSecurity( httpMethodConstraints = 
     @HttpMethodConstraint(value="POST", 
          emptyRoleSemantic=EmptyRoleSemantic.DENY ))
@BasicAuthenticationMechanismDefinition(realmName="Packt-Basic-2" )
public class ContentNoPostController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getWriter().println("GET service only...");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getWriter().println("No one will access this service...");
	}
}
