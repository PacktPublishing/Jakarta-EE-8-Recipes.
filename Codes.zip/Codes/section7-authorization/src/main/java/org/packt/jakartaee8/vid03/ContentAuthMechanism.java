package org.packt.jakartaee8.vid03;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.authentication.mechanism.http.AutoApplySession;
import javax.security.enterprise.authentication.mechanism.http.HttpAuthenticationMechanism;
import javax.security.enterprise.authentication.mechanism.http.HttpMessageContext;
import javax.security.enterprise.credential.Password;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.CredentialValidationResult.Status;
import javax.security.enterprise.identitystore.IdentityStoreHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@AutoApplySession
@ApplicationScoped
public class ContentAuthMechanism implements HttpAuthenticationMechanism {

	 @Inject
	 private IdentityStoreHandler identityStoreHandler;
	
     @Override
     public AuthenticationStatus validateRequest(HttpServletRequest request, HttpServletResponse response, HttpMessageContext httpMessageContext) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
       
        if (username != null && password != null ) {      
            Password passPwd = new Password(password);
            CredentialValidationResult result = identityStoreHandler.validate(
                new UsernamePasswordCredential(username, passPwd));

            if (result.getStatus() == Status.VALID) {       	
                return httpMessageContext.notifyContainerAboutLogin(
                    result.getCallerPrincipal(), result.getCallerGroups());
            } 
            return httpMessageContext.responseUnauthorized();
        }

        return httpMessageContext.doNothing();
    }
}
