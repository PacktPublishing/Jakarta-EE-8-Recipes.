/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	An implementation of an AJAX behavior feature. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */
package org.packt.jakartaee8.vid03;

import javax.faces.component.behavior.ClientBehaviorBase;
import javax.faces.component.behavior.ClientBehaviorContext;
import javax.faces.component.behavior.FacesBehavior;

@FacesBehavior(value = "selection", managed = true)
public class SelectMessagePopBehavior extends ClientBehaviorBase{
	
	@Override
	public String getScript(ClientBehaviorContext behaviorContext) {
		return "alert('Are you sure with the role?')";
	}
}
