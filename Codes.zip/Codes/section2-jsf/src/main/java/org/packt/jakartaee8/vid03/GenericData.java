/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A Jakarta EE bean created using CDI 2.0 and to be injected into the JSF managed beans.
 * 	
 * 
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Priority;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Alternative;
import javax.enterprise.inject.Produces;
import javax.faces.annotation.RequestParameterMap;
import javax.inject.Named;

@Dependent
@Alternative
@Priority(1)
public class GenericData {
	
	@Produces
	@RequestScoped
	@Named(value="appParam")
	@RequestParameterMap
	public Map<String, String> appParam(){
		Map<String, String> params = new HashMap<>();
		params.put("reqCustID", "1627458F");
		return params;
	}
	
	
}
