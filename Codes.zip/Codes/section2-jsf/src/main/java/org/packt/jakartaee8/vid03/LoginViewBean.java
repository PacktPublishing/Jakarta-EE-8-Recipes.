/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A JSF 2.3 viewscoped bean for the login form view page.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.packt.jakartaee8.vid05.LogAuditPublisher;
import org.packt.jakartaee8.vid05.Login;

@Login
@Named(value = "loginView")
@ViewScoped
public class LoginViewBean implements Serializable{
	
	@Inject
    private FacesContext context;
	
	@Inject
	private LogAuditPublisher logAudit;
	
	@Inject
	private LoginFormBean loginFormBean;
	
	public List<SelectItem> getUserTypes() {
        List<SelectItem> items = new ArrayList<>();
        items.add(new SelectItem("Administrator", "admin"));
        items.add(new SelectItem("Guest", "guest"));
        items.add(new SelectItem("Buyer", "buyer"));
        items.add(new SelectItem("Seller", "seller"));
        return items;
    }
	
	public String contentView(){
		logAudit.auditUser(loginFormBean.getUsername(), 
				              loginFormBean.getPassword(), LocalDate.now());
		return "/vid03/content";
	}
	
	public String getTitle() {
		
		return "JakartaEE 8";
	}
	
}
