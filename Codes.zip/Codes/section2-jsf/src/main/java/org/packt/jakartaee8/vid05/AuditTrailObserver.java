/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A sample Observer class that is invoked SYNCHRONOUSLY.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */ 

package org.packt.jakartaee8.vid05;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.inject.Named;

@Named
@RequestScoped
public class AuditTrailObserver {
	
	public void autoAudit(@Observes LogAuditEvent event) {
		System.out.println(event.logUser());
	}
}
