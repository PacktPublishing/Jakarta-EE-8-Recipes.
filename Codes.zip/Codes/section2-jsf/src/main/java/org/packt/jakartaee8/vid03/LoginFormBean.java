/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A JSF 2.3 managed bean
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.time.LocalDate;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class LoginFormBean implements Serializable{
	
	private static final long serialVersionUID = -7159847168756095084L;

	private LocalDate today;
	
	private String username;
	private String password;
	private String selected;
	
	@PostConstruct
	public void initialize() { 
		  today = LocalDate.now();
	}
	 
	public LocalDate getToday() {
		 return today;
	}
	
	public String getSelected() {
        return selected;
    }

    public void setSelected(String selected) {
        this.selected = selected;
    }
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
