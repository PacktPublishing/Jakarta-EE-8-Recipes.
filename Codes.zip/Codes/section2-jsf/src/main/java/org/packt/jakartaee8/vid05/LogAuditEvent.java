/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical event class
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */ 

package org.packt.jakartaee8.vid05;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LogAuditEvent {
	
	private String username;
	private String password;
	private LocalDate date;
	
	public LogAuditEvent(String username, String password, LocalDate date) {
		this.username = username;
		this.password = password;
		this.date = date;
	}
	public String logUser() {
		return username + ":" + password + " " + date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	}

}
