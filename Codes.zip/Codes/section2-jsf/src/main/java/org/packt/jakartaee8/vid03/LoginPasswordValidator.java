/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A JSF 2.3 validator implementation.
 * 	
 * 
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.inject.Named;

@Named(value="loginPasswordValidator")
@RequestScoped
public class LoginPasswordValidator implements Validator<String>{

	@Override
	public void validate(FacesContext context, UIComponent component, String value) throws ValidatorException {
		if (value.length() > 20) {
            throw new ValidatorException(new FacesMessage(null, "Password must be at most 20 characters"));
        }
        
        if (value.length() == 0) {
            throw new ValidatorException(new FacesMessage(null, "Password must not be empty"));
        }
	}

}
