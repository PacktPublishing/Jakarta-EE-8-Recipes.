/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A session scoped bean that highlights the use of @SessionMap.
 * 	This also highlights how to manage ALL JSF 2.3 session scoped attributes.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.faces.annotation.SessionMap;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value="sessionData")
@SessionScoped
public class SessionManagedData implements Serializable{
	
	@Inject
	@SessionMap
	private Map<String, Object> sessionScopedData;
	
	public Map<String, Object> getSessScoped(){
		sessionScopedData.put("orderId", "10101ABC");
		return sessionScopedData;
	}
	
	public String getSerialID() {
		return "JSF-123-AA";
	}
	

}
