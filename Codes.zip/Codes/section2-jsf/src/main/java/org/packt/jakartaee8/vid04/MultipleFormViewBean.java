/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A new Login view object that implements multiple forms. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 7, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.Serializable;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value = "multiFormView")
@ViewScoped
public class MultipleFormViewBean implements Serializable {
	
	 @Inject
	 private FacesContext context;
	
	 private String data1 = "";
	 private String data2 = "";
	 
	 public String getData1() {
		return data1;
	}

	public void setData1(String data1) {
		this.data1 = data1;
	}

	public String getData2() {
		return data2;
	}

	public void setData2(String data2) {
		this.data2 = data2;
	}

	public String processForm1() {
	    	System.out.println("ajax triggered by form 1...");
	        context.getPartialViewContext()
	               .getEvalScripts()
	               .add("alert('Welcome by Form 1')");
	        return "#";
	 }
	 
	 public String processForm2() {
	    	System.out.println("ajax triggered by form 2...");
	        context.getPartialViewContext()
	               .getEvalScripts()
	               .add("alert('Welcome by Form 2')");
	        return "#";
	 }
    

}
