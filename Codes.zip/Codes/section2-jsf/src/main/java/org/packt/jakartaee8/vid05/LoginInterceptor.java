package org.packt.jakartaee8.vid05;

import java.io.Serializable;

import javax.annotation.Priority;
import javax.interceptor.AroundConstruct;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Login
@Interceptor
@Priority(Interceptor.Priority.APPLICATION)
public class LoginInterceptor implements Serializable{
	
	@AroundConstruct
	public Object notifyDispatch(InvocationContext ctx) throws Exception {
		System.out.println("LoginInterceptor: logging the: " + ctx.getConstructor());
		return ctx.proceed();
	}

}
