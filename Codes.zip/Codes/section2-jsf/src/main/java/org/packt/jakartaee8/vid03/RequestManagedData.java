/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A request scoped bean that highlights the use of @RequestMap and @RequestParameterMap.
 * 	This also highlights how to manage ALL JSF 2.3 request scoped attributes and parameters.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.util.Map;

import javax.enterprise.context.RequestScoped;
import javax.faces.annotation.RequestMap;
import javax.faces.annotation.RequestParameterMap;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value="requestData")
@RequestScoped
public class RequestManagedData implements Serializable{
	
	@Inject
	@RequestMap
	private Map<String, Object> requestScopedData;
	
	public Map<String, Object> getReqScoped(){
		requestScopedData.put("Location", "Asia/Manila/Makati");
		return requestScopedData;
	}
	
	@Inject
	@Named(value="appParam")
	@RequestParameterMap
	private Map<String, String> params;
		
	public String getReqCustID(){
		return params.get("reqCustID");
	}
}
