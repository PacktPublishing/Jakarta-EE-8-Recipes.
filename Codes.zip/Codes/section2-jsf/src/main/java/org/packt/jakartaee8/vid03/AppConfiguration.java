/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A JSF 2.3 configuration class which is an application
 *  scoped bean. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */
package org.packt.jakartaee8.vid03;

import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.FacesConfig;
import javax.faces.annotation.FacesConfig.Version;

@ApplicationScoped
@FacesConfig(version=Version.JSF_2_3)
public class AppConfiguration { }
