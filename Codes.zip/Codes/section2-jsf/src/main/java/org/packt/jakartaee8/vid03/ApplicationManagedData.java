/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	An application scoped bean that highlights the use of @ApplicationMap.
 * 	This also highlights how to manage ALL JSF 2.3 application scoped attributes.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */

package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.ApplicationMap;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value="globalData")
@ApplicationScoped
public class ApplicationManagedData implements Serializable {
		
	@Inject
	@ApplicationMap
	private Map<String, Object> applicationScopedData;
	
    public Map<String, Object> getAppScoped(){
		
		applicationScopedData.put("title", "Jakarta EE 8");
		return applicationScopedData;
	}
	
	public String getTitle() {
		return "JakartaEE 8 Response";
	}
		
	
	
}
