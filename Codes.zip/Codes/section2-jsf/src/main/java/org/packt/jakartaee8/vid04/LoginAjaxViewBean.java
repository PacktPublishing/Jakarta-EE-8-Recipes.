/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A new Login view object that executes JS using <f:ajax> and eval scripts. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 7, 2018
 * 
 */

package org.packt.jakartaee8.vid04;

import java.io.Serializable;
import java.util.Map;

import javax.faces.annotation.RequestParameterMap;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value = "loginAjaxView")
@ViewScoped
public class LoginAjaxViewBean implements Serializable{

	@Inject
	@RequestParameterMap
	private Map<String, String> params;
	
	@Inject
    private FacesContext context;
		
	private String randompass;
	
    public String getRandompass() {
		return randompass;
	}

	public void setRandompass(String randompass) {
		this.randompass = randompass;
	}
	
	public void renderData(String id) {
		int random = (int)(Math.random() * 100000);
		
		String salt = params.get("salt"); 
		if(!(salt == null)) {
			randompass = id+random + salt;
		} else {
			randompass = id + random;
		}
		
	}
	
	public String validateUser(String user, String role) {
        context.getPartialViewContext()
        	   .getRenderIds()
        	   .add("loginForm");
        
        // Eval Script
        // trivial client-side validation here
        context.getPartialViewContext()
               .getEvalScripts()
               .add("alert('User "+ user +" is a/an valid "+ role +"');");
        
        return "#";
    }
	
}
