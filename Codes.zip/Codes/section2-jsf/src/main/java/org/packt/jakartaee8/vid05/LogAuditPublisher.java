/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A Jakarta EE request scoped attributes that will fire the event for audit
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 5, 2018
 * 
 */ 


package org.packt.jakartaee8.vid05;

import java.time.LocalDate;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
public class LogAuditPublisher {
	
	@HighSeverity
	@Inject
	private Event<LogAuditEvent> logAuditEvent;
	
	public void auditUser(String username, String password, LocalDate today) {
		logAuditEvent.fire(new LogAuditEvent(username, password, today));
	}
	

}
