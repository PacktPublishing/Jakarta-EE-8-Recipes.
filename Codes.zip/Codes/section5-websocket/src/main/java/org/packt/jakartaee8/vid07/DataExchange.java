package org.packt.jakartaee8.vid07;

import java.io.IOException;

import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/exchange")
public class DataExchange {
	
	@Inject
	private Event<WebSocketMsg> webSocktEvent;
	
	private String[] responses = {"How do I help you?", "Anything more?", "We will response to you ASAP sir/maam!"};
    private static int counter = 0;
    @OnOpen
    public void onOpen(Session session) {
        System.out.println("onOpen: " + session.getId()); 
        
        session.addMessageHandler(String.class,(msg)->{
        	 try {
                 session.getBasicRemote().sendText(responses[(counter++)%3]);
                 webSocktEvent.fireAsync(new WebSocketMsg(msg));
        	 } catch (IOException e) {
                 e.printStackTrace();
             }
        });
        
    }
    @OnClose
    public void onClose(Session session) {
        System.out.println("onClose:" +  session.getId());
        
    }
    // if you want to use onMessage below, comment the addMessageHandler above
    /*
    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("onMessage sent by: " + session.getId() + " Message=" + message);
        
             try {
               session.getBasicRemote().sendText(responses[(counter++)%3]);
               webSocktEvent.fireAsync(new WebSocketMsg(msg));
        	 } catch (IOException e) {
               e.printStackTrace();
             }
    }
    */
    @OnError
    public void onError(Throwable t) {
        System.out.println("onError:" + t.getMessage());
    }
}