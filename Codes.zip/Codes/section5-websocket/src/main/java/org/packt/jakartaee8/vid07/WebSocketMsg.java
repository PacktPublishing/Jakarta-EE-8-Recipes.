package org.packt.jakartaee8.vid07;

public class WebSocketMsg {
	
	private String message;
	
	public WebSocketMsg(String msg) {
		this.message = msg;
	}
	
	public String getMessage() {
		return message;
	}
}
