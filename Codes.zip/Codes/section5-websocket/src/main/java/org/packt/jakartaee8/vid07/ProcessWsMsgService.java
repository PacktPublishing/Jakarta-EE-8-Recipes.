package org.packt.jakartaee8.vid07;

import java.time.LocalDate;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;

@RequestScoped
public class ProcessWsMsgService {
	
	public void saveWSMessage(@ObservesAsync WebSocketMsg wsMsg) {
		System.out.println(LocalDate.now() +" : " +wsMsg.getMessage());
	}
}
