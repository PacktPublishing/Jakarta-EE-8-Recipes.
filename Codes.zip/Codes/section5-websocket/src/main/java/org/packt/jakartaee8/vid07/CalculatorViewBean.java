package org.packt.jakartaee8.vid07;

import java.io.Serializable;
import java.time.LocalDate;

import javax.faces.push.Push;
import javax.faces.push.PushContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@ViewScoped
@Named("calcViewBean")
public class CalculatorViewBean implements Serializable{

	@Inject
	@Push(channel="calcChannel")
	private PushContext calcChannel;
	
	private String operand1;
	private String operand2;
	private String result = "0";
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getOperand1() {
		return operand1;
	}

	public void setOperand1(String operand1) {
		this.operand1 = operand1;
	}

	public String getOperand2() {
		return operand2;
	}
	
	public void setOperand2(String operand2) {
		this.operand2 = operand2;
	}
	
	public void sendCalcAdd() {
		calcChannel.send("Sum is: " + calculateAdd(operand1, operand2) + " @ " + LocalDate.now());
	}
	
	public void sendCalcDiff() {
		calcChannel.send("Diff is: " + calculateDiff(operand1, operand2) + " @ " + LocalDate.now());
	}
	
	private int calculateAdd(String op1, String op2) {
		int val1, val2 = 0;
		try {
			val1 = Integer.parseInt(op1);
			val2 = Integer.parseInt(op2);
		} catch(Exception e) {
			val1 = 0;
			val2 = 0;
		}
		result = (val1 + val2) + "";
		return val1 + val2;
	}
	
	private int calculateDiff(String op1, String op2) {
		int val1, val2 = 0;
		try {
			val1 = Integer.parseInt(op1);
			val2 = Integer.parseInt(op2);
		} catch(Exception e) {
			val1 = 0;
			val2 = 0;
		}
		result = (val1 - val2) + "";
		return val1 - val2;
	}

}
