package org.packt.jakartaee8.vid07;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.faces.event.WebsocketEvent;
import javax.faces.event.WebsocketEvent.Closed;
import javax.faces.event.WebsocketEvent.Opened;

@ApplicationScoped
public class WebSocketCommObserver {


    public void onOpen(@Observes @Opened WebsocketEvent opened) {
       System.out.println("event opened: " + opened);
    }

    public void onClose(@Observes @Closed WebsocketEvent closed) {
    	 System.out.println("event closed: " + closed);
    }

}
