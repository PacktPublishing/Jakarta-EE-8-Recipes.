package org.packt.jakartaee8.vid07;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.faces.push.Push;
import javax.faces.push.PushContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@ViewScoped
@Named("messengerViewBean")
public class MessengerViewBean implements Serializable{

	@Inject
    @Push
    PushContext chatChannel;
	
	private String message;

    public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void chat() {
		chatChannel.send("What can I do for you, " + message + "?");
    }
}
