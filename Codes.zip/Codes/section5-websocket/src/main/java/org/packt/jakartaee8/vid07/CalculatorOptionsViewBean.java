package org.packt.jakartaee8.vid07;

import java.io.Serializable;

import javax.faces.event.AbortProcessingException;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.push.Push;
import javax.faces.push.PushContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@ViewScoped
@Named("calcOptViewBean")
public class CalculatorOptionsViewBean implements Serializable{

	@Inject
	@Push(channel="typicalAjaxChannel")
	PushContext typicalAjaxChannel;

	@Inject
	@Push(channel="listenerAjaxChannel")
	PushContext listenerAjaxChannel;

	@Inject
	@Push(channel="cmdScriptAjaxChannel")
	PushContext cmdScriptAjaxChannel;
	
	private String operand1;
	private String operand2;
	private String result;
	private String operationUsed;
	
	public String getOperand1() {
		return operand1;
	}

	public void setOperand1(String operand1) {
		this.operand1 = operand1;
	}

	public String getOperand2() {
		return operand2;
	}

	public void setOperand2(String operand2) {
		this.operand2 = operand2;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getOperationUsed() {
		return operationUsed;
	}

	public void setOperationUsed(String operationUsed) {
		this.operationUsed = operationUsed;
	}

	
	 
	 private int calculateAdd(String op1, String op2) {
			int val1, val2 = 0;
			try {
				val1 = Integer.parseInt(op1);
				val2 = Integer.parseInt(op2);
			} catch(Exception e) {
				val1 = 0;
				val2 = 0;
			}
			result = (val1 + val2) + "";
			return val1 + val2;
			
	}
		
	private int calculateDiff(String op1, String op2) {
		int val1, val2 = 0;
		try {
			val1 = Integer.parseInt(op1);
			val2 = Integer.parseInt(op2);
		} catch(Exception e) {
			val1 = 0;
			val2 = 0;
		}
		result = (val1 - val2) + "";
		return val1 - val2;
			
	}
		
	private int calculateMul(String op1, String op2) {
		int val1, val2 = 0;
		try {
			val1 = Integer.parseInt(op1);
			val2 = Integer.parseInt(op2);
		} catch(Exception e) {
			val1 = 0;
			val2 = 0;
		}
		result = (val1 * val2) + "";
		return val1 * val2;
	}
		
	public void onSubtractObserve(AjaxBehaviorEvent e) throws AbortProcessingException{
		calculateDiff(operand1, operand2);
		operationUsed = "Subtraction executed by an f:ajax listener";
	   }

	  public void cmdMultplyOp() {
	    calculateMul(operand1, operand2);
	    operationUsed = "Multiplication executed by f:commandScript";
	  }
	    
	   public void execTypicalChannel() {  
	    operationUsed = "Addition triggered by f:ajax";
	    calculateAdd(operand1, operand2);
	    typicalAjaxChannel.send("ajaxEvent");
	   }
	    
	  public void execListenerAjaxChannel(){ 
	   listenerAjaxChannel.send("myCustomListenerEvent");
	    	
	  }
	    
	 public void execCmdAjaxChannel() {
	   cmdScriptAjaxChannel.send("myCmdScriptOp");
	 }


}
