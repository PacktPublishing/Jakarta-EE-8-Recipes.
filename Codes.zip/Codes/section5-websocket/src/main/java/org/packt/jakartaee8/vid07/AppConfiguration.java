package org.packt.jakartaee8.vid07;

import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.FacesConfig;
import javax.faces.annotation.FacesConfig.Version;

@ApplicationScoped
@FacesConfig(version=Version.JSF_2_3)
public class AppConfiguration { }
