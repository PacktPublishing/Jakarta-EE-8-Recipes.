package org.packt.jakartaee8.vid07;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.faces.push.Push;
import javax.faces.push.PushContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("sessionScopedViewBean")
@ViewScoped
public class SessScopedMsgViewBean implements Serializable{

	@Inject
	@Push(channel="sessChannel")
	private PushContext sessionContext;
	
	 public void pushToSessionChannel() {
		 sessionContext.send("sent to sessionChannel at ::" + LocalDateTime.now());
	    }
}
