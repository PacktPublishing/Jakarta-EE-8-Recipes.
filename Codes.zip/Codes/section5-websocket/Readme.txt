****************************************************************
                           DESCRIPTION
****************************************************************
These are the codes implemented, created, used, and demonstrated
in the Section 5 videos. Running these whole project will give 
you unwanted results. So run and test each package one at a time 
or separately.
****************************************************************
                           TOOLS
****************************************************************
 - Java version used is Java 10
 - Application server used is Apache TomEE 8
 - Database system used is Mysql 8.0.12 for Win64 on x86_64 (MySQL Community Server - GPL)
 - Can only execute using HTTP/1.1
