/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical POJO when used in EJB session beans. 
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.io.Serializable;

import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.json.bind.config.PropertyOrderStrategy;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@JsonbPropertyOrder(PropertyOrderStrategy.ANY)
public class Product implements Serializable{
	
	@Id
    @JsonbProperty(value="id", nillable=false)
	private Integer id;
    
    @Column
    @JsonbProperty(value="name", nillable=false)
	private String name;
    
    @Column
    @JsonbProperty(value="price", nillable=false)
	private Double price;
	
    public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}

}
