package org.packt.jakartaee8.vid03;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonPointer;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.JsonValue;

import org.packt.jakartaee8.vid01.Product;
import org.packt.jakartaee8.vid01.ProductDao;
import org.packt.jakartaee8.vid01.ProductDaoImpl;

@Named
@RequestScoped
public class ProdJsonPointerService {

	@Named(value="productDao")
	@Inject
	private ProductDao productDao;
	
	public void init() {
		productDao = new ProductDaoImpl();
		productDao.init();
	}
	
	public String searchJsonById(int index)  {
		JsonArray jsonData = Json.createArrayBuilder().build(); // immutable
		JsonArrayBuilder jsonDataBuilder = 
				Json.createArrayBuilder(jsonData);
		for(Product rec : productDao.listProducts()) {
			JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", rec.getId())
					.add("name", rec.getName())
					.add("price", rec.getPrice())
					.build();
			jsonDataBuilder.add(jsonRow);
		}
		jsonData = jsonDataBuilder.build();
		 
		JsonPointer pointer = Json.createPointer("/"+ index);
		JsonObject prod = pointer.getValue(jsonData).asJsonObject();
		return prod.toString();
	}
	
	public String searchProdNameById(String jsonFile, int index) 
			throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		 
		JsonPointer pointer = Json.createPointer("/" + index + "/name");
		JsonValue prod = pointer.getValue(products);
		
		return prod.toString();
	}
	
	public String addProdToJson(String jsonFile, int index, Product newProd) 
			 throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		
		JsonObject jsonProd = Json.createObjectBuilder()
				.add("id", newProd.getId())
				.add("name", newProd.getName())
				.add("price", newProd.getPrice())
				.build();
		
		JsonPointer pointer = Json.createPointer("/"+ index);
		JsonArray prodArray = pointer.add(products.asJsonArray(), jsonProd);
		return prodArray.toString();
	}
	
	public String updatePriceJsonProd(String jsonFile, int index, double newPrice) 
			throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		 
		JsonPointer pointer = Json.createPointer("/"+ index +"/price");
		JsonArray prodArray = pointer.replace(products.asJsonArray(), 
				Json.createValue(newPrice));
		return prodArray.toString();
	}
	
	public String removeProdFromJson(String jsonFile, int index) 
			throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		
		JsonPointer pointer = Json.createPointer("/"+ index);
		JsonArray prodArray = pointer.remove(products.asJsonArray());
		
		return prodArray.toString();
	}
	

}
