package org.packt.jakartaee8.vid04;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonMergePatch;
import javax.json.JsonObject;
import javax.json.JsonPatch;
import javax.json.JsonPatchBuilder;
import javax.json.JsonReader;
import javax.json.JsonStructure;

import org.packt.jakartaee8.vid01.Product;
import org.packt.jakartaee8.vid01.ProductDao;
import org.packt.jakartaee8.vid01.ProductDaoImpl;

@Named
@RequestScoped
public class ProdJsonPatchService {
	
	@Named(value="productDao")
	@Inject
	private ProductDao productDao;
	
	public void init() {
		productDao = new ProductDaoImpl();
		productDao.init();
	}
	
	public String addJsonPatch(String jsonFile, int row, int delRow, 
			Product newProd) throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		
		JsonObject jsonProd = Json.createObjectBuilder()
				.add("id", newProd.getId())
				.add("name", newProd.getName())
				.add("price", newProd.getPrice())
				.build();
		

		JsonObject op1 = Json.createObjectBuilder()
				.add("op", "add")
				.add("path", "/" + row)
				.add("value", jsonProd)
				.build();
		
		JsonObject op2 = Json.createObjectBuilder()
				.add("op", "remove")
				.add("path", "/" + delRow)
				.build();
		
		
		JsonArray patches = Json.createArrayBuilder()
				.add(op1)
				.add(op2)
				.build();
		
		JsonPatch jsonPatch = Json.createPatch(patches);
		JsonArray result = jsonPatch.apply(products.asJsonArray());
		return result.toString();
	}
	
	public String transformJsonData(String jsonFile, 
			Product newProd, Double newPrice, int newRow,
			int delRow, int copyRow1, int copyRow2, int replaceRow,
			int moveRow1, int moveRow2) throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		
		JsonObject jsonProd = Json.createObjectBuilder()
				.add("id", newProd.getId())
				.add("name", newProd.getName())
				.add("price", newProd.getPrice())
				.build();
		
		JsonPatchBuilder patchBuilder = Json.createPatchBuilder();
		
		JsonPatch jsonPatch = patchBuilder
				.add("/" + newRow, jsonProd)
				.replace("/" + replaceRow + "/price", Json.createValue(newPrice))
				.remove("/" + delRow)
				.copy("/" + copyRow1, "/" + copyRow2)
				.move("/" + moveRow1, "/" + moveRow2)
				.build();
		
		JsonStructure newProducts = jsonPatch.apply(products);
		return newProducts.toString();
	}
	
	public String conditionalJsonPatch(String jsonFile, 
			String targetName, int index1, int index2) throws FileNotFoundException {
		JsonReader reader = Json.createReader(new FileReader(jsonFile));
		JsonStructure products = reader.read();
		
		JsonPatchBuilder patchBuilder = Json.createPatchBuilder();
		JsonPatch jsonPatch = patchBuilder
				.test("/" + index1 + "/name", targetName)
				.copy("/" + index2, "/" + index1)
				.build();
		
		JsonStructure newProducts = jsonPatch.apply(products);
		return newProducts.toString();
		
	}
	
	public String fileMergePatch(String targetFile, String patchFile) 
			throws FileNotFoundException {
		
		JsonReader reader = Json.createReader(new FileReader(patchFile));
		JsonStructure patch = reader.read();
		
		JsonReader targetReader = Json.createReader(new FileReader(targetFile));
		JsonStructure target = targetReader.read();
		
		JsonMergePatch jsonMergePatch = Json.createMergePatch(patch);
		JsonObject jsonObj = jsonMergePatch.apply(target).asJsonObject();
		
		return jsonObj.toString();
	}
		
     public String fileMergeDiffPatch(String targetFile, String patchFile) throws FileNotFoundException {
		
		JsonReader reader = Json.createReader(new FileReader(patchFile));
		JsonStructure patch = reader.read();
		
		JsonReader targetReader = Json.createReader(new FileReader(targetFile));
		JsonStructure target = targetReader.read();
		
		JsonMergePatch jsonMergePatch = Json.createMergeDiff(target, patch);
		JsonObject jsonObj = jsonMergePatch.apply(target).asJsonObject();
		
		return jsonObj.toString();
	}
	
	
		

}
