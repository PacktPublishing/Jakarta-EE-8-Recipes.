package org.packt.jakartaee8.vid05;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.stream.JsonCollectors;
import javax.json.stream.JsonParser;

import org.packt.jakartaee8.vid01.Product;
import org.packt.jakartaee8.vid01.ProductDao;
import org.packt.jakartaee8.vid01.ProductDaoImpl;

@Named
@RequestScoped
public class ProdJsonQueryService {
	
	@Named(value="productDao")
	@Inject
	private ProductDao productDao;
	
	public void init() {
		productDao = new ProductDaoImpl();
		productDao.init();
	}
	
	public String searchByName(String name) {
		JsonArray jsonData = Json.createArrayBuilder().build(); 
		JsonArrayBuilder jsonDataBuilder = 
				Json.createArrayBuilder(jsonData);
		for(Product rec : productDao.listProducts()) {
			JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", rec.getId())
					.add("name", rec.getName())
					.add("price", rec.getPrice())
					.build();
			jsonDataBuilder.add(jsonRow);
		}
		jsonData = jsonDataBuilder.build();
		
		return jsonData.getValuesAs(JsonObject.class)
				   .stream()
				   .filter((p) ->
				        p.getJsonString("name").equals(Json.createValue(name)))
				   .collect(JsonCollectors.toJsonArray()).toString();
	}
	
	public String searchByPrice(String jsonFile, double price) 
			throws FileNotFoundException {
		JsonParser parser = Json.createParser(new FileReader(jsonFile));
		String jsonData = "";
		while (parser.hasNext()) {
			 if (parser.next() == JsonParser.Event.START_ARRAY) {
		    	jsonData= parser.getArrayStream()
		          .map(v->v.asJsonObject())
		          .filter(obj->obj.getJsonNumber("price")
		        		  .equals(Json.createValue(price)))
		          .collect(JsonCollectors.toJsonArray()).toString();
		          parser.skipArray();
		     }
		}
		return jsonData;
	}
	
	public String getProductName(String jsonFile) 
			throws FileNotFoundException {
		Product p = new Product();
		JsonParser parser = Json.createParser(new FileReader(jsonFile));
		String jsonData = "";
		while (parser.hasNext()) {
			 if (parser.next() == JsonParser.Event.START_OBJECT) {
		    	jsonData= parser.getObjectStream()
		    		.filter(entry->entry.getKey().equalsIgnoreCase("name"))
		            .map(entry->entry.getValue())
		            .findFirst()
		            .get().toString();
		     }
		}
		return jsonData;
	}
	
	
	
}
