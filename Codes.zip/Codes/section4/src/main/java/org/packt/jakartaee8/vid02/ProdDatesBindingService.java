package org.packt.jakartaee8.vid02;

import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;

@Named
@RequestScoped
public class ProdDatesBindingService implements Serializable{
	
	public String convertDatesToJson(ProductDates prod) {
		Jsonb jsonb = JsonbBuilder.create();		
		return jsonb.toJson(prod).toString();
	}

}
