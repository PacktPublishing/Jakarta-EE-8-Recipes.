package org.packt.jakartaee8.vid01;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbException;

@Named
@RequestScoped
public class ProductJsonService implements Serializable{

	@Named(value="productDao")
	@Inject
	private ProductDao productDao;
	
	public void init() {
		productDao = new ProductDaoImpl();
		productDao.init();
	}
	
	public String getJsonProduct(int id) {
		Jsonb jsonb = JsonbBuilder.create();
		Product prod = productDao.getProduct(id);
		String json = jsonb.toJson(prod);
		return json;
	}
	
	public String getJsonProds() {
		Jsonb jsonb = JsonbBuilder.create();
		List<Product> prods = productDao.listProducts();
		String json = jsonb.toJson(prods);
		return json;
	}
	
	public Product getFromJsonFile(String jsonFile) 
			throws JsonbException, FileNotFoundException {
		Jsonb jsonb = JsonbBuilder.create();
		Product prod = jsonb.fromJson(new FileReader(jsonFile), Product.class);
		return prod;
	}
	
	public List<Product> getListFromJsonFile(String jsonFile) 
			throws JsonbException, FileNotFoundException {
		Jsonb jsonb = JsonbBuilder.create();
		Type carrierListType = 
				new ArrayList<Product>(){}.getClass().getGenericSuperclass();
		List<Product> prods = jsonb.fromJson(new FileReader(jsonFile), carrierListType);
		return prods;
	}
	
	public void createListFromJsonFile(File jsonFile) 
			throws JsonbException, IOException {
		Jsonb jsonb = JsonbBuilder.create();
		List<Product> prods = productDao.listProducts();
		jsonb.toJson(prods, new FileWriter(jsonFile));
		
	}
	
	// JSON-P
	
	public String buildJsonProduct(int id) {
		Product p = productDao.getProduct(id);
		JsonObject jsonProd = Json.createObjectBuilder()
				.add("id", p.getId())
				.add("name", p.getName())
				.add("price", p.getPrice())
				.build();
		return jsonProd.toString();
	}
	
	public String getJsonProducts(){
		JsonArray jsonData = Json.createArrayBuilder().build(); // immutable
		JsonArrayBuilder jsonDataBuilder = 
				Json.createArrayBuilder(jsonData);
		for(Product rec : productDao.listProducts()) {
			JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", rec.getId())
					.add("name", rec.getName())
					.add("price", rec.getPrice())
					.build();
			jsonDataBuilder.add(jsonRow);
		}
		jsonData = jsonDataBuilder.build();
		return jsonData.toString();
	}
	
	
	
	public String buildJsonProducts(List<Product> p) {
		JsonArray jsonData = Json.createArrayBuilder().build(); // immutable
		JsonArrayBuilder jsonDataBuilder = Json.createArrayBuilder(jsonData);
		for(Product rec : p) {
			JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", rec.getId())
					.add("name", rec.getName())
					.add("price", rec.getPrice())
					.build();
			jsonDataBuilder.add(jsonRow);
		}
		jsonData = jsonDataBuilder.build();
		return jsonData.toString();
	}
	
	public String buildAndRemoveJsonProducts(int row) {
		List<Product> prods = productDao.listProducts();
		JsonArray jsonData = Json.createArrayBuilder().build(); // immutable
		JsonArrayBuilder jsonDataBuilder = Json.createArrayBuilder(jsonData);
		for(Product rec : prods) {
			JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", rec.getId())
					.add("name", rec.getName())
					.add("price", rec.getPrice())
					.build();
			jsonDataBuilder.add(jsonRow);
		}
		jsonData = jsonDataBuilder.remove(row).build();
		return jsonData.toString();
	}
	
	public String buildAndUpdateJsonProducts(int row, Product newProd) {
		List<Product> prods = productDao.listProducts();
		JsonArray jsonData = Json.createArrayBuilder().build(); // immutable
		JsonArrayBuilder jsonDataBuilder = Json.createArrayBuilder(jsonData);
		for(Product rec : prods) {
			JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", rec.getId())
					.add("name", rec.getName())
					.add("price", rec.getPrice())
					.build();
			jsonDataBuilder.add(jsonRow);
		}
		
		JsonObject newJsonRec = Json.createObjectBuilder()
				.add("id", newProd.getId())
				.add("name", newProd.getName())
				.add("price", newProd.getPrice())
				.build();
		
		jsonData = jsonDataBuilder.set(row, newJsonRec).build();
		return jsonData.toString();
	}
    
	
}
