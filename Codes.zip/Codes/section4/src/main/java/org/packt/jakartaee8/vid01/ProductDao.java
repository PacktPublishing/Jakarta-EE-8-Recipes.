/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is the remote interface used in the JNDI access of the ProductServiceBean EJB.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.util.List;

public interface ProductDao {
	public void addProduct(Product prod) ;
	public int deleteProduct(Product prod) ;
	public int updateProduct(Product prod) ;
	public List<Product> listProducts() ;
	public Product getProduct(int id);
	public List<String> listProdNames();
	public void init();
}
