package org.packt.jakartaee8.vid03;

import java.io.FileNotFoundException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.packt.jakartaee8.vid01.Product;

@RunWith(JUnit4.class)
public class TestProdJsonPointerService {
	
	private ProdJsonPointerService jsonPointerService;
	
	@Before
    public void setUp() {
		jsonPointerService = new ProdJsonPointerService();
		jsonPointerService.init();
    }
	
	@After
    public void tearDown() {
		jsonPointerService = null;
    }
	
	@Test
	public void testSearchJsonById() {
		String jsonProd = jsonPointerService.searchJsonById(0);
		System.out.println(jsonProd);
	}
	
	@Test
	public void testSearchProdNameById() {
		String jsonProd;
		try {
			jsonProd = jsonPointerService.searchProdNameById(
					"./src/main/resources/json/products.json", 1);
			System.out.println(jsonProd);
		} catch (FileNotFoundException e) {
		}
		
	}
	
	@Test
	public void testAddProdToJson() {
		try {
			Product p = new Product();
			p.setId(567);
			p.setName("GoProMax");
			p.setPrice(66789.9);
			System.out.println(jsonPointerService.addProdToJson(
					"./src/main/resources/json/products.json", 0, p));
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testUpdatePriceJsonProd() {
		try {
			System.out.println(jsonPointerService.updatePriceJsonProd(
					"./src/main/resources/json/products.json", 1, 89.00));
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testRemoveProdFromJson() {
		try {
			System.out.println(jsonPointerService.removeProdFromJson
					("./src/main/resources/json/products.json", 1));
		} catch (FileNotFoundException e) {	}
	}
	

}
