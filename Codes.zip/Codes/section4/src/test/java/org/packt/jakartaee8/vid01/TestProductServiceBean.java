package org.packt.jakartaee8.vid01;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.json.bind.JsonbException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class TestProductServiceBean {
	
	private ProductJsonService productJsonService;
	
	@Before
    public void setUp() {
		productJsonService = new ProductJsonService();
		productJsonService.init();
    }
	
	@After
    public void tearDown() {
		productJsonService = null;
    }
	
	@Test
	public void testGetJsonProduct() {
		System.out.println(productJsonService.getJsonProduct(10));
	}
	
	@Test
	public void testGetJsonProds() {
		System.out.println(productJsonService.getJsonProds());
	}
	
	@Test
	public void testGetFromJsonFile() {
		try {
			Product p = 
					productJsonService.getFromJsonFile("./src/main/resources/json/product.json");
			System.out.println(p.getName());
		} catch (JsonbException e) {
			
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testListFromJsonFile() {
		try {
			List<Product> prods = 
					productJsonService.getListFromJsonFile("./src/main/resources/json/products.json");
		    prods.forEach((p)->{
		    	System.out.format("%d %s\n", p.getId(), p.getName());
		    });
			
		} catch (JsonbException e) {
			
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testCreateListFromJsonFile() {
		File file = new File("./src/main/resources/json/prodlist.json");
		try {
			productJsonService.createListFromJsonFile(file);
		} catch (JsonbException e) {
			
		} catch (FileNotFoundException e) {	
			
		} catch (IOException e) {	}
	}
	
	
	
	@Test
	public void testBuildJsonProduct() {
		String jsonProd = productJsonService.buildJsonProduct(10);
		System.out.println(jsonProd);
	}
	
	@Test
	public void testGetJsonProducts() {
		String jsonListProds = productJsonService.getJsonProducts();
		System.out.println(jsonListProds);
	}
	
	@Test
	public void testBuildAndRemoveJsonProducts() {
		String jsonListProds = productJsonService.buildAndRemoveJsonProducts(0);
		System.out.println(jsonListProds);
	}
	
	@Test
	public void testbuildAndUpdateJsonProducts() {
		Product newProd = new Product();
		newProd.setId(6789);
		newProd.setName("Ginger Tab");
		newProd.setPrice(6789.35);
		String jsonListProds = productJsonService.buildAndUpdateJsonProducts(0, newProd);
		System.out.println(jsonListProds);
	}

}
