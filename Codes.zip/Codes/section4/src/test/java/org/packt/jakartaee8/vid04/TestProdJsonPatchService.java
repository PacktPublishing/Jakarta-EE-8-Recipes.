package org.packt.jakartaee8.vid04;

import java.io.FileNotFoundException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.packt.jakartaee8.vid01.Product;

@RunWith(JUnit4.class)
public class TestProdJsonPatchService {
	
	private ProdJsonPatchService jsonPatchService;
	
	@Before
    public void setUp() {
		jsonPatchService = new ProdJsonPatchService();
		jsonPatchService.init();
    }
	
	@After
    public void tearDown() {
		jsonPatchService = null;
    }
	
	@Test
	public void testAddJsonPatch() {
		Product p = new Product();
		p.setId(567);
		p.setName("GoProMax");
		p.setPrice(66789.9);
		try {
			String jsonData = jsonPatchService.addJsonPatch(
					"./src/main/resources/json/products.json", 0, 1, p);
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testTransformJsonData() {
		Product p = new Product();
		p.setId(567);
		p.setName("GoProMax");
		p.setPrice(66789.9);
		try {
			String jsonData = jsonPatchService.transformJsonData(
					"./src/main/resources/json/products.json", p, 333.33, 
					     0, 1, 1, 2, 0, 0, 1);
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testConditionalJsonPatch() {
		
		try {
			String jsonData = jsonPatchService.conditionalJsonPatch(
					"./src/main/resources/json/products.json", "Bike", 0, 1);
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testMergePatch() {
		
		try {
			String jsonData = jsonPatchService.fileMergePatch(
					"./src/main/resources/json/target.json", 
					"./src/main/resources/json/patch.json");
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testFileMergeDiffPatch() {
		
		try {
			String jsonData = jsonPatchService.fileMergeDiffPatch(
					"./src/main/resources/json/target.json", 
					"./src/main/resources/json/patch.json");
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
}
