package org.packt.jakartaee8.vid02;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.util.Calendar;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class TestProdDatesBindingService {
	
	private ProdDatesBindingService datesBindingService;
	
	@Before
    public void setUp() {
		datesBindingService = new ProdDatesBindingService();
    }
	
	@After
    public void tearDown() {
		datesBindingService = null;
    }
	
	@Test
	public void testConvertDatesToJson() {
		ProductDates prodDates = new ProductDates();
		
		Calendar now = Calendar.getInstance();
		Date today = now.getTime();
		LocalDateTime ldt = LocalDateTime.now();
		LocalDate ld = LocalDate.now();
		LocalTime lt = LocalTime.now();
		Instant instant = Instant.now();
		Period afterThree = Period.ofMonths(3);
		Duration afterTwo = Duration.ofSeconds(2);
		
		prodDates.setDate(today);
		prodDates.setCal(now);
		prodDates.setLocalDateTime(ldt);
		prodDates.setLocalDate(ld);
		prodDates.setLocalTime(lt);
		prodDates.setInstant(instant);
		prodDates.setPeriod(afterThree);
		prodDates.setDuration(afterTwo);
		
		String jsonData = datesBindingService.convertDatesToJson(prodDates);
		System.out.println(jsonData);
	}

}
