package org.packt.jakartaee8.vid05;

import java.io.FileNotFoundException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

@RunWith(JUnit4.class)
public class TestProdJsonQueryService {
	
	private ProdJsonQueryService jsonQueryService;
	
	@Before
    public void setUp() {
		jsonQueryService = new ProdJsonQueryService();
		jsonQueryService.init();
    }
	
	@After
    public void tearDown() {
		jsonQueryService = null;
    }
	
	@Test
	public void testSearchByName() {
		String jsonData = jsonQueryService.searchByName("Bike");
		System.out.println(jsonData);
	}
	
	@Test
	public void testSearchByPrice() {
		try {
			String jsonData = jsonQueryService
					.searchByPrice("./src/main/resources/json/products.json", 2346.89);
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
	@Test
	public void testGetProductName() {
		try {
			String jsonData = jsonQueryService
					.getProductName("./src/main/resources/json/product.json");
			System.out.println(jsonData);
		} catch (FileNotFoundException e) {	}
	}
	
	
}
