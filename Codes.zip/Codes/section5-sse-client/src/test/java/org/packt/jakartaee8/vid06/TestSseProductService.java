package org.packt.jakartaee8.vid06;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.sse.InboundSseEvent;
import javax.ws.rs.sse.SseEventSource;

import org.junit.Test;

public class TestSseProductService {
	
	@Test
    public void testSseProdJson() {
    	
    	WebTarget target = ClientBuilder.newClient()
    			.target("http://localhost:8080/sec5sse/sse/prodjson/10");

    	try (SseEventSource eventSource = SseEventSource.target(target)
    			.reconnectingEvery(2, TimeUnit.SECONDS).build()) {
    			    eventSource.register(new Consumer<InboundSseEvent>(){
    			    	@Override
    			    	public void accept(InboundSseEvent event) {
    			    		Product p = event.readData(Product.class);
    			    		System.out.println("Product : " + p.getName());
    			    	}
    			    }, new Consumer<Throwable>(){

    			    	@Override
    			    	public void accept(Throwable t) {
    			    		t.printStackTrace();
    			    	}
    			    }, new Runnable() {

    			    	@Override
    			    	public void run() {
    			    		System.out.println("Client consumption done");                            
    			    }
    			});
 
            eventSource.open();
            
            try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	 
    	}
    	
    	
    }
        
    @Test
    public void testssebroadcast() {
    	Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8080/sec5sse/sse/prodjson/10");
        
        try (SseEventSource source = SseEventSource.target(target).build()) {
            source.register(this::extractMessage);
            source.open();
            Thread.sleep(500);
        } catch (InterruptedException e) {

        }
    }
    
    private void extractMessage(InboundSseEvent event) {
    	String id = event.getId();
        String name = event.getName();
        String payload = event.readData();
        String comment = event.getComment();
        System.out.println("Product is: "+payload);
    }
   
}
