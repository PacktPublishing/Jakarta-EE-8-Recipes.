package org.packt.jakartaee8.vid06;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/mylogout.html")
public class LogoutController extends HttpServlet{
	
	@Inject
	private HttpSession session;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		session.invalidate();
		// enable the comment below if you want to explicitly delete the cookies
		/*
		Cookie[] cookies = req.getCookies();
		for(Cookie cookie : cookies) {
			if(cookie.getName().equalsIgnoreCase("jsessionid") ||
					cookie.getName().equalsIgnoreCase("jremembermeid")) {
				cookie.setMaxAge(0);
				resp.addCookie(cookie);
			}
		}
		*/
		req.getRequestDispatcher("/mylogin.html").forward(req, resp);
	}

}
