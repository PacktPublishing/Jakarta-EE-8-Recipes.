/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical POJO class.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

public class Location {
	
	private String locPost;
	private String locName;
	private String regionName;
	
	public String getLocPost() {
		return locPost;
	}
	public void setLocPost(String locPost) {
		this.locPost = locPost;
	}
	public String getLocName() {
		return locName;
	}
	public void setLocName(String locName) {
		this.locName = locName;
	}
	public String getRegionName() {
		return regionName;
	}
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	
	

}
