package org.packt.jakartaee8.vid06;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.security.enterprise.CallerPrincipal;
import javax.security.enterprise.credential.RememberMeCredential;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.Pbkdf2PasswordHash;
import javax.security.enterprise.identitystore.RememberMeIdentityStore;

@ApplicationScoped
public class ContentRememberMeIdentityStore implements RememberMeIdentityStore {

    private final Map<String, CredentialValidationResult> identities = 
    		new ConcurrentHashMap<>();

    @Inject
    private Pbkdf2PasswordHash pbkdf2PasswordHash;
    
    @Override
    public CredentialValidationResult validate(RememberMeCredential credential) {
        System.out.println("identities: " +identities);
    	if (identities.containsKey(credential.getToken())) {
    		System.out.println("token found...");
            return identities.get(credential.getToken());
        }

        return CredentialValidationResult.INVALID_RESULT;
    }

    @Override
    public String generateLoginToken(CallerPrincipal callerPrincipal, Set<String> groups) {
        // String token = UUID.randomUUID().toString();
        String token = pbkdf2PasswordHash.generate(callerPrincipal.getName().toCharArray());
        identities.put(token, new CredentialValidationResult(callerPrincipal, groups));
        return token;
    }

    @Override
    public void removeLoginToken(String token) {
        identities.remove(token);
    }

}