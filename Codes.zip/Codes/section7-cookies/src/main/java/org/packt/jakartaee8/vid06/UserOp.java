/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	A typical class with static methods.
 * 	
 *  
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 2, 2018
 * 
 */

package org.packt.jakartaee8.vid06;

public class UserOp {
	
	public static String generateUserId(String user, String pass) {
		return String.join("", "USER-", 
				user.charAt(0)+"", pass.charAt(0)+"").toUpperCase();
	}

}
