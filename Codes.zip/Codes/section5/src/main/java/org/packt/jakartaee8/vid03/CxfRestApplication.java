package org.packt.jakartaee8.vid03;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("")
public class CxfRestApplication extends Application { }