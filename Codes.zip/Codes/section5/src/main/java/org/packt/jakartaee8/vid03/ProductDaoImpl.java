package org.packt.jakartaee8.vid03;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

@Named(value="productDao")
@RequestScoped
public class ProductDaoImpl implements ProductDao {
	
	@PersistenceContext(unitName="jakartaEEPU")
	private EntityManager em;
	
	@Inject
	private UserTransaction utx;
	 
	@Override
	public void addProduct(Product prod) {
		try {
			utx.begin();
			em.persist(prod);
			utx.commit();
			em.clear();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.clear();
		}
	}

	@Override
	public int deleteProduct(int id) {
		Product pToDel = new Product();
		try {
			pToDel = em.find(Product.class, id);
			utx.begin();
			em.remove(pToDel);
			utx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.clear();
		}
		return pToDel.getId();
	}

	@Override
	public int updateProduct(Product prod){
		try {
			utx.begin();
			em.merge(prod);
			utx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			em.clear();
		}
	  return prod.getId();
	}

	@Override
	public List<Product> listProducts() {
		return em.createQuery("SELECT p FROM Product p").getResultList();
	}

	@Override
	public Product getProduct(int id) {
		Product product = em.find(Product.class, id);
		return product;
	}

}
