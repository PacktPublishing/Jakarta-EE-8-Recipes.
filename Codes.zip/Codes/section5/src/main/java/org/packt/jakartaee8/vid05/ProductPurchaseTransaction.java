package org.packt.jakartaee8.vid05;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;
import javax.inject.Inject;
import javax.inject.Named;

import org.packt.jakartaee8.vid03.ProductDao;

@RequestScoped
public class ProductPurchaseTransaction {
	
	@Inject
	@Named("productDao")
	private ProductDao productDao;
	
	public void purchase(@ObservesAsync ProductPurchaseEvent pEvent) throws Exception{
		productDao.addProduct(pEvent.getProduct());
	} 

}
