package org.packt.jakartaee8.vid05;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;

@RequestScoped
public class MgtConfirmLedgerTransaction {
	
	public void createAuditLog(@ObservesAsync NotificationEvent nEvent) {
		System.out.println("Generated ledge item dated: " + nEvent.getPurchaseDate());
	}

}
