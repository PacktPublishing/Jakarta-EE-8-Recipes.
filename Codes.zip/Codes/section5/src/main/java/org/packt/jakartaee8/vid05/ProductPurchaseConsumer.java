package org.packt.jakartaee8.vid05;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.packt.jakartaee8.vid03.Product;

@MessageDriven(activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "destination", propertyValue = "MyQueue")})
public class ProductPurchaseConsumer implements MessageListener{

	@Inject
	private Event<ProductPurchaseEvent> asyncEvent;
	
	@Override
	public void onMessage(Message message) {
		MapMessage msg = (MapMessage) message;
	       
        Product prod = new Product();
        try {
        	System.out.println(msg.getInt("prodId"));
			prod.setId(msg.getInt("prodId"));
			prod.setName(msg.getString("prodName"));
		    prod.setPrice(msg.getDouble("prodPrice"));
		    asyncEvent.fireAsync(new ProductPurchaseEvent(prod))
		          .whenComplete((event, err) -> {
			    if (err != null) {
			        System.out.println("Encountered an error: "+err.getMessage());
			    } else {
			        System.out.println("ProductDb event ended successfully.");
			    }
			});
		   
		} catch (JMSException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

}
