package org.packt.jakartaee8.vid05;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSDestinationDefinition;
import javax.jms.JMSDestinationDefinitions;
import javax.jms.Topic;

import org.packt.jakartaee8.vid03.Product;

@JMSDestinationDefinitions(
        value = {
           @JMSDestinationDefinition(
             name = "MyTopic",
             interfaceName = "javax.jms.Topic",
             destinationName = "MyTopic"
        )
    })
@Stateless(name="notification")
public class NotificationService {
	
	 @Inject 
	 @JMSConnectionFactory("MyJmsConnectionFactory")
	 private JMSContext jmsContext;
	
	 @Resource(name = "MyTopic") 
	 private Topic topic;
	  
	 @Inject
	 private Event<NotificationEvent> asyncEvent;

	 @PostConstruct
	 public void buildEventSubscribers() {
	   jmsContext.createConsumer(topic)
		  .setMessageListener((p)->{
			  asyncEvent.fireAsync(new NotificationEvent(LocalDate.now(), "verified"));
			  
		  });
	  }
	 
	 public void generateFileRecords(Product prod) {
		 final Map<String, Object> message = new HashMap<>();
	        message.put("prodId", prod.getId());
	        message.put("prodName", prod.getName());
	        message.put("prodPrice", prod.getPrice());
		 jmsContext.createProducer().send(topic, message);
		 System.out.println("Sending the product details for filing...");
		 jmsContext.close();
	 }

}
