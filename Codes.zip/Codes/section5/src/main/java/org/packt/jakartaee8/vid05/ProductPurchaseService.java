package org.packt.jakartaee8.vid05;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.JMSDestinationDefinition;
import javax.jms.JMSDestinationDefinitions;
import javax.jms.Queue;

import org.packt.jakartaee8.vid03.Product;

@JMSDestinationDefinitions(
        value = {
            @JMSDestinationDefinition(
                    name = "MyQueue",
                    interfaceName = "javax.jms.Queue",
                    destinationName = "MyQueue"
            )
        }
)
@Stateless(name="purchaseProduct")
public class ProductPurchaseService {
	
	@Inject 
	@JMSConnectionFactory("MyJmsConnectionFactory")
	private JMSContext jmsContext;
	
	@Resource(name = "MyQueue") 
	private Queue queue;
	
	public void addPurchaseProd(Product prod) {
		final Map<String, Object> message = new HashMap<>();
        message.put("prodId", prod.getId());
        message.put("prodName", prod.getName());
        message.put("prodPrice", prod.getPrice());
        jmsContext.createProducer().send(queue, message);
        System.out.println("Sending the purchased product details...");
        jmsContext.close();
	}
}
