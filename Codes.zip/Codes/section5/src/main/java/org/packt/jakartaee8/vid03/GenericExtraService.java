package org.packt.jakartaee8.vid03;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/addendum")
public class GenericExtraService {
		
	@GET
    @Produces("application/java-byte-code")
	@Path("/reflect/eval/{option}")
    public Class<?> evalClassUtil(
   		 @PathParam("option") Integer option) {
		 if(option == 0) {
			 return Product.class;
		 }else if (option == 1) {
			 return Location.class;
		 }
   	 return Object.class;
	 }

}
