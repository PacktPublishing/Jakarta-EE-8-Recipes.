package org.packt.jakartaee8.vid01;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbException;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/purchase.html", asyncSupported=true)
public class PurchaseController extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		System.out.println("start of servlet");
		Integer id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		Double price = Double.parseDouble(req.getParameter("price"));
		
		Product prod = new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		System.out.println(Thread.currentThread().getName());
		AsyncContext asyncContext = req.startAsync(req,resp);
		//asyncContext.setTimeout(10);
		Runnable asyncDispatchProcess = () ->{
			    System.out.println(Thread.currentThread().getName());
				System.out.println("start of asynchronous process");
				saveOrder(prod, (HttpServletResponse) asyncContext.getResponse());
				System.out.println("end of asynchronous process");
				asyncContext.complete();
		};
			
		asyncContext.start (asyncDispatchProcess);
		req.setAttribute("dateOrdered", LocalDateTime.now());
		req.setAttribute("totalOrder", 1);
		System.out.println("end of servlet");
        req.getRequestDispatcher("/vid01/prod_purchase.jsp").forward(req, resp);
	}
	
	private void saveOrder(Product prod, HttpServletResponse resp) {
		 try {
			    Path tempFile = Files.createTempFile("product", ".json");
			    Jsonb jsonb = JsonbBuilder.create();
			    jsonb.toJson(prod, new FileWriter(tempFile.toFile()));
			    resp.getWriter().println("<br/>Generated JSON data!");
			    TimeUnit.SECONDS.sleep(10);
	        } catch (InterruptedException e) {
	            Thread.interrupted();
	        } catch (JsonbException e) { }
		      catch (IOException e) { }
		 
			
	}

}
