package org.packt.jakartaee8.vid03;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/async")
public class ProdAsyncDaoService {
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@Resource
    private ManagedExecutorService executor;
	
	@GET
	@Path("/product/list")
	@Produces(MediaType.APPLICATION_JSON)
	public CompletionStage<List<Product>> getAsyncListProd(){
		 CompletionStage<List<Product>> prodCS = 
			CompletableFuture.supplyAsync(() -> {
				 List<Product> prods = productDao.listProducts();
				 try {
				     Thread.sleep(100);
				 } catch (InterruptedException ex) {   }
				 
				 return prods;
			});
		 return prodCS;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("/product/{id}")
	public CompletionStage<Product> 
	      getAsyncProduct(@PathParam("id") final Integer id) {
		
		CompletableFuture<Product> filterProduct = 
				CompletableFuture.supplyAsync(() -> 
				   productDao.getProduct(id));
		return filterProduct;
    }
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/add")
    public Product asyncAddProduct(@FormParam("id") Integer id, 
    					 @FormParam("name") String name, 
    					 @FormParam("price") Double price) {
        Product prod = new Product();
        prod.setId(id);
        prod.setName(name);
        prod.setPrice(price);
       
        CompletableFuture.runAsync(()->{
        	 try {
     			productDao.addProduct(prod);
     		} catch (Exception e) { }
        });
        return prod;
    }

}
