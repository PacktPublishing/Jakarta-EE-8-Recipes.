package org.packt.jakartaee8.vid02;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.packt.jakartaee8.vid01.Product;

@WebServlet(urlPatterns="/search2.html", asyncSupported=true)
public class SearchController extends HttpServlet {
		
	private Executor executorService = ForkJoinPool.commonPool();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		System.out.println("start of servlet");
		PrintWriter out = resp.getWriter();
		
		Integer id = Integer.parseInt(req.getParameter("id"));
		
		Supplier<Product> asyncProcessProd = () ->{
			Product p = searchSupplies(id, resp);
			System.out.println("supplier: " + p.getName());
			return p;
		};
		
		Function<Product,String> prodName =
			(prod)->{ 
				System.out.println("function: " + prod.getName());
				return prod.getName();
				};
				
		Consumer<String> printName = 
				(name) ->{ 
					req.setAttribute("dateSearched",LocalDate.now());
					req.setAttribute("name", name);						 	
			};
			
		BiConsumer<Void, Throwable> consume = (result, ex)->{
			try {
				resp.getWriter().println(result);
				System.out.println("end of asynchronous process");
			} catch (IOException e) { }
					
			if(!(ex == null)) {
					ex.printStackTrace();
				}
			};
			
		CompletableFuture<Product> asyncTasks = CompletableFuture
				.supplyAsync(asyncProcessProd, executorService);
		
		asyncTasks.thenApplyAsync(prodName)
				.thenAcceptAsync(printName)
				.whenCompleteAsync(consume);
		
		try {
			asyncTasks.get();
		} catch (InterruptedException e) {	
		} catch (ExecutionException e) {  }
		
		System.out.println("end of servlet");
		req.getRequestDispatcher("/vid02/prod_search.jsp").forward(req, resp);
	}

	private Product searchSupplies(Integer id, HttpServletResponse resp) {
		Product prod = new Product();
		prod.setId(id);
		prod.setName("Bike");
		prod.setPrice(4400.78);
		try {
			  TimeUnit.SECONDS.sleep(10);
	    } catch (InterruptedException e) {
	          Thread.interrupted();
	    } 
		return prod;
	}

}
