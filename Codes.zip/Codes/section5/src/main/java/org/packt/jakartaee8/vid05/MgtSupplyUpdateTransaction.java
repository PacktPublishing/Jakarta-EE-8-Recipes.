package org.packt.jakartaee8.vid05;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;

@RequestScoped
public class MgtSupplyUpdateTransaction {
	
	public void commandWarehouse(@ObservesAsync NotificationEvent nEvent) {
		System.out.println("Supply needed due to purchase done this: " + nEvent.getPurchaseDate());
	}

}
