package org.packt.jakartaee8.vid05;

import java.time.LocalDate;

public class NotificationEvent {
	private LocalDate purchaseDate;
	private String status;
	
	public NotificationEvent(LocalDate purchaseDate, String status) {
		this.purchaseDate = purchaseDate;
		this.status = status;
	}
	
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}

	public String getStatus() {
		return status;
	}


}
