package org.packt.jakartaee8.vid05;

import org.packt.jakartaee8.vid03.Product;

public class ProductPurchaseEvent {
	
	private Product product;
	
	public ProductPurchaseEvent(Product product) {
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

}
