package org.packt.jakartaee8.vid03;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

@Path("/dao")
public class ProdDaoService {
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@GET
	@Path("/product/list")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Product> listProducts() {
        return productDao.listProducts();
    }
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("/product/filter/{id}")
    public Product filterProduct(@PathParam("id") int id) {
		return productDao.getProduct(id);
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/remove/{id}")
	public Product removeProduct(@PathParam("id") int id) {
		Product delProd = new Product();
		try {
			delProd = productDao.getProduct(id);
			productDao.deleteProduct(id);
		} catch (Exception e) {	}
		 
		return delProd;
	 }

	 @PUT
	 @Consumes(MediaType.APPLICATION_JSON)
	 @Path("/product/update")
	 public Product updateProduct(Product prod) {
		 try {
			productDao.updateProduct(prod);
		} catch (Exception e) {
			
		}
		 return prod;
	 }
	 
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/addjson")
	public Product addProductJson(Product prod) {
		try {
			productDao.addProduct(prod);
		} catch (Exception e) {	}
		return prod;
	}
	 
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/product/addform")
	public Product addProduct(MultivaluedMap<String, String> params) {
		Product prod = new Product();
		try {
			prod.setId(Integer.parseInt(params.getFirst("id")));
			prod.setName(params.getFirst("name"));
			prod.setPrice(Double.parseDouble(params.getFirst("price")));
			productDao.addProduct(prod);
		} catch (Exception e) {	}
		return prod;
	 }
			
	
		
	 
	 @PATCH
	 @Consumes(MediaType.APPLICATION_JSON)
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/product/filter/patch/{id}")
	 public Product filterPatchProduct(Product prod, 
			 @PathParam("id") Integer id) {
	     try {
	    	prod.setId(id);
	    	System.out.println(prod);
			productDao.updateProduct(prod);
		} catch (Exception e) {	}
		 return productDao.getProduct(id);
	 }
	 
	 
	 



}
