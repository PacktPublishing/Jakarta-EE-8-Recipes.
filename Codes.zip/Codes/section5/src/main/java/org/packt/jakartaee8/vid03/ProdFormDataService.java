package org.packt.jakartaee8.vid03;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/form")
public class ProdFormDataService {
	
	@GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_PLAIN)
    @Path("{pathParam}")
    public String pathParam(@PathParam("pathParam") String pathParam) {
        return pathParam;
    }
	
	@POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_PLAIN)
    public String queryParam(@QueryParam("myparam") String queryParam) {
        return queryParam;
    }
}
