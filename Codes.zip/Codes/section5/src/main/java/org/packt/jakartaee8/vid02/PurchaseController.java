package org.packt.jakartaee8.vid02;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.packt.jakartaee8.vid01.Product;

@WebServlet(urlPatterns="/purchase2.html", asyncSupported=true)
public class PurchaseController extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		
		System.out.println("start of servlet");
		Integer id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		Double price = Double.parseDouble(req.getParameter("price"));
		
		Product prod = new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		System.out.println("Main thread: " + Thread.currentThread().getName());
		Runnable asyncDispatchProcess = () ->{
			System.out.println("runAsync thread: " +Thread.currentThread().getName());
			System.out.println("start of asynchronous process");
			saveOrder(prod, resp);			
		};
		
		CompletionStage<Void> asyncTask = 
				CompletableFuture.runAsync(asyncDispatchProcess);
		BiConsumer<Void, Throwable> consume = (result, ex)->{
			System.out.println("whenComplete thread: " + Thread.currentThread().getName());
			System.out.println("end of asynchronous process");
			if(!(ex == null)) {
				ex.printStackTrace();
			}
		};
		asyncTask.whenComplete(consume);
		
		req.setAttribute("dateOrdered", LocalDateTime.now());
		req.setAttribute("totalOrder", 1);
		System.out.println("end of servlet");
        req.getRequestDispatcher("/vid02/prod_purchase.jsp").forward(req, resp);
	}
	
	private void saveOrder(Product prod, HttpServletResponse resp) {
		 try {
			    Path tempFile = Files.createTempFile("product", ".json");
			    Jsonb jsonb = JsonbBuilder.create();
			    jsonb.toJson(prod, new FileWriter(tempFile.toFile()));
			    resp.getWriter().println("<br/>Generated JSON data!");
			    TimeUnit.SECONDS.sleep(10);
	        } catch (InterruptedException e) {
	            Thread.interrupted();
	        } catch (JsonbException e) { }
		      catch (IOException e) { }
		 
			
	}

}
