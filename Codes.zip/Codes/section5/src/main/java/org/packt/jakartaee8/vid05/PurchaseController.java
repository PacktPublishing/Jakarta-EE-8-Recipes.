package org.packt.jakartaee8.vid05;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.packt.jakartaee8.vid03.Product;

@WebServlet(urlPatterns="/purchase3.html", asyncSupported=true)
public class PurchaseController extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	private ProductPurchaseService purchaseService;
	private NotificationService notifyService;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		Integer id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		Double price = Double.parseDouble(req.getParameter("price"));
		
		try {
			InitialContext ic=new InitialContext();
			Object obj= (ProductPurchaseService)ic.lookup("java:app/sec5/purchaseProduct");       		
			purchaseService=(ProductPurchaseService) obj;
			
			Object obj2 = (NotificationService)ic.lookup("java:app/sec5/notification");       		
			notifyService = (NotificationService) obj2;
		}catch(NamingException ex) {
			ex.printStackTrace();
		}
		
		Product prod = new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		purchaseService.addPurchaseProd(prod);
		notifyService.generateFileRecords(prod);
		
		req.getRequestDispatcher("/vid05/prod_purchase.jsp").forward(req, resp);
	}
	
	

}
