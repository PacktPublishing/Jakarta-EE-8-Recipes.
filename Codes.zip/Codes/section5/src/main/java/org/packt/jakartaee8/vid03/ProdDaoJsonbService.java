package org.packt.jakartaee8.vid03;

import javax.inject.Inject;
import javax.inject.Named;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/json")
public class ProdDaoJsonbService {
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@GET
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/product/filter/{id}")
	 public JsonObject jsonFilterProduct(@PathParam("id") Integer id) {
		 Product prod = productDao.getProduct(id);
		 JsonObject jsonRow = Json.createObjectBuilder()
					.add("id", prod.getId())
					.add("name", prod.getName())
					.add("price", prod.getPrice())
					.build();
		 return jsonRow;
	 }
	 
	 @GET
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/product/list")
	 public JsonArray jsonProductArray() {
		 JsonArray jsonData = Json.createArrayBuilder().build(); // immutable
			JsonArrayBuilder jsonDataBuilder = Json.createArrayBuilder(jsonData);
			for(Product rec : productDao.listProducts()) {
				JsonObject jsonRow = Json.createObjectBuilder()
						.add("id", rec.getId())
						.add("name", rec.getName())
						.add("price", rec.getPrice())
						.build();
				jsonDataBuilder.add(jsonRow);
			}
			jsonData = jsonDataBuilder.build();
		 return jsonData;
	 }

}
