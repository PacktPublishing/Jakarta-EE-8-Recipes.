package org.packt.jakartaee8.vid05;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;

@RequestScoped
public class MgtPurchaseLogTransaction {
	
	public void createLog(@ObservesAsync NotificationEvent nEvent) {
		System.out.println("Purchased a " + nEvent.getStatus() + " product.");
	}

}
