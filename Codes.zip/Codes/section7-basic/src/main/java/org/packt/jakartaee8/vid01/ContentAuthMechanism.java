package org.packt.jakartaee8.vid01;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.authentication.mechanism.http.AutoApplySession;
import javax.security.enterprise.authentication.mechanism.http.HttpAuthenticationMechanism;
import javax.security.enterprise.authentication.mechanism.http.HttpMessageContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@AutoApplySession
@ApplicationScoped
public class ContentAuthMechanism implements HttpAuthenticationMechanism {

	private Map<String, String> users;
	private Map<String, Set<String>> roles;
	
	@PostConstruct
	public void init() {
		users = new HashMap<>();
		roles = new HashMap<>();
		users.put("admin", "admin");
		users.put("sjctrags", "sjctrags");
		users.put("guest", "guest");
		
		roles.put("admin", new HashSet<>(Arrays.asList("administrator")));
		roles.put("sjctrags", new HashSet<>(Arrays.asList("user")));
		roles.put("guest", new HashSet<>(Arrays.asList("guest")));
	}
		 
    @Override
    public AuthenticationStatus validateRequest(HttpServletRequest request, HttpServletResponse response, HttpMessageContext httpMessageContext) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
       
        if (username != null && password != null ) {
        	 if(users.containsKey(username)  ) {
        		 if(users.get(username).equals(password)) {
        			 return httpMessageContext.notifyContainerAboutLogin(
        	                    username, roles.get(username));
        		 }
        	 }
                
            return httpMessageContext.responseUnauthorized();
        
        }
        return httpMessageContext.doNothing();
    }
}
