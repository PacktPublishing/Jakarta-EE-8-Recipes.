package org.packt.jakartaee8.vid02;

import java.util.List;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

@Named(value="productDao2")
@RequestScoped
public class ProductDaoImpl implements ProductDao {
	
	@PersistenceContext(unitName="jakartaEEPUJTA")
	private EntityManager em;
	 
	@Inject
	private UserTransaction utx;
	
	@Inject
    private Validator validator;

	@Override
	public void addProduct(Product prod){
		try {
			utx.begin();
			em.persist(prod);
			utx.commit();
			
		} catch (ConstraintViolationException e) {
			try {
				utx.rollback();
				Set<ConstraintViolation<Product>> violations = validator.validate(prod);
				for (ConstraintViolation<Product> violation : violations) {
				    System.out.println(violation.getInvalidValue()); 
				}		
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}
				
		} catch (Exception e) {
			try {
				utx.rollback();
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}
		} finally {
			em.clear();
		}
	}

	@Override
	public int deleteProduct(Product prod) {
		try {
			Product pToDel = em.find(Product.class, prod.getId());
			utx.begin();
			em.remove(pToDel);
			utx.commit();
		} catch (ConstraintViolationException e) {
			try {
				utx.rollback();
				Set<ConstraintViolation<Product>> violations = validator.validate(prod);
				for (ConstraintViolation<Product> violation : violations) {
				    System.out.println(violation.getInvalidValue()); 
				}		
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}			
		} catch (Exception e) {
			try {
				utx.rollback();
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}
		} finally {
			em.clear();
		}
		
		return prod.getId();
	}

	@Override
	public int updateProduct(Product prod) {
		try {
			utx.begin();
			em.merge(prod);
			utx.commit();
		} catch (ConstraintViolationException e) {
			try {
				utx.rollback();
				Set<ConstraintViolation<Product>> violations = validator.validate(prod);
				for (ConstraintViolation<Product> violation : violations) {
				    System.out.println(violation.getInvalidValue()); 
				}		
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}					
		} catch (Exception e) {
			try {
				utx.rollback();
			}  catch (Exception e1) {
				System.out.println("Other reason: " + e1.getMessage());
			}
		} finally {
			em.clear();
		}
		return prod.getId();
	}

	@Override
	public List<Product> listProducts() {
		return em.createQuery("SELECT p FROM Product p").getResultList();
	}

}
