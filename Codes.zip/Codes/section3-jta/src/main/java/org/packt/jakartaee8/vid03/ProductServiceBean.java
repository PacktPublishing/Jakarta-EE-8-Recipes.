package org.packt.jakartaee8.vid03;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.inject.Named;

import org.packt.jakartaee8.vid02.Product;
import org.packt.jakartaee8.vid02.ProductDao;

@Stateless(name="productService")
//@TransactionManagement(value=TransactionManagementType.CONTAINER)
@TransactionManagement(value=TransactionManagementType.BEAN)
public class ProductServiceBean implements ProductService{
	
	@Inject
	@Named(value="productDao3")
	private ProductDao productDao;

	@Override
	//@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public void setProduct(Product prod) throws Exception {
		productDao.addProduct(prod);
	}

	@Override
	//@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public int removeProduct(Product prod) throws Exception {
		return productDao.deleteProduct(prod);
	}

	@Override
	//@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public int changeProduct(Product prod) throws Exception {
		return productDao.updateProduct(prod);
	}

	@Override
	//@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Product> getProducts() {
		return productDao.listProducts();
	}

}
