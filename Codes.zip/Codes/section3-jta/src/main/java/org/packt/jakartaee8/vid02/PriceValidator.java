package org.packt.jakartaee8.vid02;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PriceValidator implements ConstraintValidator<ProdPrice, Double> {

	protected double minPrice;
	
    @Override
    public void initialize(ProdPrice priceVal) {
        this.minPrice = priceVal.value();
    }

	@Override
	public boolean isValid(Double value, ConstraintValidatorContext context) {
		if(value < minPrice) {
			return false;
		}
		return true;
	}

}
