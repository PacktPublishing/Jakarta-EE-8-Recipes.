package org.packt.jakartaee8.vid03;

import java.util.List;

import javax.ejb.Remote;

import org.packt.jakartaee8.vid02.Product;

@Remote
public interface ProductService {
	
	public void setProduct(Product prod) throws Exception;
	public int removeProduct(Product prod) throws Exception;
	public int changeProduct(Product prod) throws Exception;
	public List<Product> getProducts() ;

}
