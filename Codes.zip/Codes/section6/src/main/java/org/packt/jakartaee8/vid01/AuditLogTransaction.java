/**
 * 	<h1>Packt Publishing - JakartaEE 8 Recipes</h1>
 * 	This is a sample EJB stateful EJB session bean that fires an event ASYNCHRONOUSLY.
 * 	
 *  @author Sherwin John Tragura
 *  @version 1.0
 *  @since December 4, 2018
 * 
 */

package org.packt.jakartaee8.vid01;

import java.io.Serializable;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.enterprise.event.NotificationOptions;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
public class AuditLogTransaction implements Serializable{
		
	private static final long serialVersionUID = 1L;

	@Inject
    private Event<OrderClosedEvent> event;
	
	private final Executor executor = Executors.newFixedThreadPool(3);
	
	public void proceedOrderAsync(String message) {
		event.fireAsync(new OrderClosedEvent("order phase started"), 
				  NotificationOptions.ofExecutor(executor))
		.thenAccept((event)->{
			System.out.println("Thread: " + Thread.currentThread().getName());
			System.out.println("Audit event ended successfully.");
		});
	}
	
	public void proceedOrderAsyncWithExec(String message) {
		event.fireAsync(new OrderClosedEvent("order phase started"))
		.whenCompleteAsync((event, err) -> {
			System.out.println("Thread: " + Thread.currentThread().getName());
		    if (err != null) {
		        System.out.println("Encountered an erro: "+err.getMessage());
		    } else {
		        System.out.println("Audit event ended successfully.");
		    }
		}, executor);
		
	}
}
