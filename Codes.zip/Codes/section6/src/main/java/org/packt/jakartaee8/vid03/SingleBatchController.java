package org.packt.jakartaee8.vid03;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/batch")
public class SingleBatchController extends HttpServlet{
	
	private BatchProcessBean batchProcess;
	
	 @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 try {
				InitialContext jndi = new InitialContext();
				batchProcess = (BatchProcessBean)jndi.lookup("java:app/sec6/batchProcess");
				batchProcess.createOneTimeBatch();
				batchProcess.createSingleBatch();;
			} catch (NamingException e) {
				e.printStackTrace();
			}
		 resp.getWriter().println("triggered batch...");
	}

}
