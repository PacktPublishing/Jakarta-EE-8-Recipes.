package org.packt.jakartaee8.vid03;

import java.util.List;

import org.packt.jakartaee8.vid01.Product;

public class ProductNotification {
	
	private List<Product> prods;
	
	public ProductNotification(List<Product> prods) {
		this.prods = prods;
	}
	
	public List<Product> getProds(){
		return prods;
	}

}
