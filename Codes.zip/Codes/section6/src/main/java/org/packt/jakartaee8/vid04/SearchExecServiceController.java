package org.packt.jakartaee8.vid04;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedThreadFactory;
import javax.servlet.AsyncContext;
import javax.servlet.AsyncEvent;
import javax.servlet.AsyncListener;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/search4.html", asyncSupported=true)
public class SearchExecServiceController extends HttpServlet {

	//private ExecutorService executor = Executors.newFixedThreadPool(10);
	
	@Resource(name="myJakartaEETF")
	private ManagedThreadFactory threadFactory;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		System.out.println("start of servlet");
		PrintWriter out = resp.getWriter();
			
		AsyncContext asyncContext = req.startAsync(req,resp);
		asyncContext.setTimeout(100);
		asyncContext.addListener(new SearchAsyncListener());
		Runnable asyncSearchProcess = () ->{
			System.out.println("start of asynchronous processing: " 
					+ Thread.currentThread().getName());
			String dispatchPath;
			try {
				searchSupplies((HttpServletResponse) asyncContext.getResponse());
				dispatchPath = "/vid04/prod_async_search.jsp";
			} catch (Exception e) {
				dispatchPath = "/vid04/error.jsp";
			}
			
			asyncContext.dispatch(dispatchPath);
			
		};
		
		ExecutorService executor = Executors.newFixedThreadPool(10, threadFactory);				
		executor.submit(asyncSearchProcess);
	    int numRejectedTasks = executor.shutdownNow().size();
	    
		try {
			executor.awaitTermination(500, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("No of tasks rejected after shutdown: " + numRejectedTasks);
		System.out.println("end of servlet");
	}

	public class SearchAsyncListener implements AsyncListener{
		@Override
		public void onComplete(AsyncEvent event) throws IOException {
			System.out.println("end of asynchronous processing");
			
		}
		@Override
		public void onTimeout(AsyncEvent event) throws IOException {
			System.out.println("timeout");
	        event.getAsyncContext().dispatch("/vid01/error.jsp"); 
		}

		@Override
		public void onError(AsyncEvent event) throws IOException {
			System.out.println("error");
	        event.getAsyncContext().dispatch("/vid01/error.jsp"); 
		}

		@Override
		public void onStartAsync(AsyncEvent event) throws IOException {
			System.out.println("Async");
		}
	}
	

	private void searchSupplies(HttpServletResponse resp) {
		 try {
			    resp.getWriter().println("<h1>Search Result</h1>");
			 	resp.getWriter().println("<p> At <em>"+LocalDate.now()+"</em>,");
			    resp.getWriter().println(" there are <em>"+100+"</em> products searched.");
			    TimeUnit.SECONDS.sleep(10);
	        } catch (InterruptedException e) {
	            Thread.interrupted();
	        } catch (IOException e) {
				
			}
		  
	}

}
