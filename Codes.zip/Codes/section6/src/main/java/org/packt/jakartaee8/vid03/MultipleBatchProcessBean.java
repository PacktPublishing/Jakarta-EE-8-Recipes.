package org.packt.jakartaee8.vid03;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedScheduledExecutorService;

@Stateless(name="multBatchProcess")
public class MultipleBatchProcessBean {
	
	public double discount = 0;
	public double price = 0;
	public double markup = 0;
	
	@Resource(name="myJakartaEEScheduledMES")
	private ManagedScheduledExecutorService scheduledExecutor;
	
	public void createBatches() {
		Runnable computeDiscountTask = ()->{
			discount += 0.05;
			System.out.println("discount increased to: " + discount);
		};
		
		Runnable computeMarkupTask = () ->{
			markup += 1.00;
			System.out.println("markup now is: " + markup);
		};
		
		Runnable computePriceTask = ()-> {
			price += markup * discount;
			System.out.println("price is now: " + price);
		};
		
		scheduledExecutor.scheduleAtFixedRate(computeDiscountTask, 5, 5, TimeUnit.SECONDS);
		scheduledExecutor.scheduleAtFixedRate(computeMarkupTask, 1, 7, TimeUnit.SECONDS);
		scheduledExecutor.scheduleWithFixedDelay(computePriceTask, 1, 6, TimeUnit.SECONDS);
	}

}
