package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedScheduledExecutorService;

@Stateless(name="batchProcess")
public class BatchProcessBean implements Serializable{
	
	private double result = 1;
	
	@Resource(name="myJakartaEEScheduledMES")
	private ManagedScheduledExecutorService scheduledExecutor;
	
	
	public void createSingleBatch() {
		Runnable computeTask = () ->{
			result *= (Math.PI* 200) + 100;
			System.out.println("Computation result is: " +result);
		};
		
		scheduledExecutor.scheduleAtFixedRate(computeTask, 3, 5, TimeUnit.SECONDS);
	}
	
	public void createOneTimeBatch() {
		Callable<Double> callComputeTask = () ->{
			result *= (Math.PI* 200) + 100;
			return result;
		};
		ScheduledFuture<Double> result = scheduledExecutor.schedule(callComputeTask, 5, TimeUnit.SECONDS);
		
		try {
			System.out.println("Single result is: " +result.get());
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	}

}
