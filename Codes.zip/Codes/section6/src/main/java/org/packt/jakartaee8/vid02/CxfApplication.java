package org.packt.jakartaee8.vid02;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("")
public class CxfApplication extends Application {
	    
}