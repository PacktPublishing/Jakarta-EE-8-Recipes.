package org.packt.jakartaee8.vid03;

import java.time.LocalDateTime;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.ObservesAsync;

@RequestScoped
public class MonitorProducts {

	public void listenIncomingProds(@ObservesAsync ProductNotification prodNotify) {
		System.out.println("Recieved updated list at " + LocalDateTime.now());
	}
}
