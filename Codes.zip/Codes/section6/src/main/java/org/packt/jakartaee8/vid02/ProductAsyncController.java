package org.packt.jakartaee8.vid02;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.packt.jakartaee8.vid01.ProductDao;

@WebServlet("/async.html")
public class ProductAsyncController extends HttpServlet{
	
	@Resource(name="myJakartaEEMES")
    private ManagedExecutorService executor;
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		Callable<Object> prodNamesTask = ()-> {
			System.out.println("Processing ProductDao...");
			return  productDao.listProducts()
				  .stream().map((p) -> p.getName()).sorted().collect(Collectors.toList());
		};
		Callable<Object> prodSizeTask =()-> {
			System.out.println("Getting product size...");
			return productDao.listProducts().size();
		};
		
		Callable<Object> runComplete = ()-> {
			System.out.println("Done processing...");
			return true;
		};
		
		Collection<Callable<Object>> tasks = new HashSet<>();
		tasks.add(runComplete);
		tasks.add(prodSizeTask);
		tasks.add(prodNamesTask);
		
		try {
		   Collection<Future<Object>> results = executor.invokeAll(tasks);
		   results.stream().forEach((future)->{
			   Object data;
			   try {
				   data = future.get();
				   if(data instanceof Collection) {
					   System.out.println("Products: " + data + " by " + Thread.currentThread().getName());
				   } else if(data instanceof Boolean) {
					   System.out.println("Complete: " + data + " by " + Thread.currentThread().getName());
				   } else if(data instanceof Integer) {
					   System.out.println("Product size: " + data + " by " + Thread.currentThread().getName());
				   }
			   } catch (InterruptedException e) {
				   e.printStackTrace();
			   } catch (ExecutionException e) {
				   e.printStackTrace();
			   }
			   
		   });
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	
		out.println("done processing tasks....");
	}

}
