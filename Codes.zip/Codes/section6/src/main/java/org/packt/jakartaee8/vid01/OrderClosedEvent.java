package org.packt.jakartaee8.vid01;

public class OrderClosedEvent {
	
	private String message;
	
	public OrderClosedEvent(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}

}
