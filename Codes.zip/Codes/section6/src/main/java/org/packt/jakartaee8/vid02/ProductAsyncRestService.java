package org.packt.jakartaee8.vid02;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Function;

import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.packt.jakartaee8.vid01.Product;
import org.packt.jakartaee8.vid01.ProductDao;

@Path("/async")
public class ProductAsyncRestService {
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@Resource(name="myJakartaEEMES")
    private ManagedExecutorService executor;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
    @Path("/product/{id}")
	public CompletionStage<Product> getReactiveProduct(@PathParam("id") final Integer id) {
		
			
        System.out.println("Thread [main]: " + Thread.currentThread().getName());

        CompletableFuture<Boolean> checkProduct = new CompletableFuture<>();

        CompletableFuture<Product> filterProduct = checkProduct.thenComposeAsync(
                new Function<Boolean, CompletionStage<Product>>() {
                	@Override
                	public CompletionStage<Product> apply(Boolean t) {
                		System.out.println("Thread filter: " + Thread.currentThread().getName());
                		return CompletableFuture.supplyAsync(() -> productDao.getProduct(id), executor);
                }
        }, executor);
        
        CompletableFuture<String> fetchProduct = filterProduct.thenApplyAsync(
                (product) ->{ 
                	System.out.println("Thread fetch: " + Thread.currentThread().getName());
                	return productDao.getProduct(id).getName(); 
                }, executor);

        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                	System.out.println("Thread complete: " + Thread.currentThread().getName());
                	checkProduct.complete(true);
                } catch (Exception ex) {
                    
                }
            }
        });
        
        return filterProduct;
    }
	
	
}
