package org.packt.jakartaee8.vid01;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/prodlist.html", asyncSupported=true)
public class ProductsController extends HttpServlet{
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	private ExecutorService executor = Executors.newFixedThreadPool(10);
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		System.out.println("start of servlet");
		PrintWriter out = resp.getWriter();
		
		AsyncContext asyncContext = req.startAsync(req,resp);
		
		Callable<List<Product>> processList = ()-> {
			System.out.println("start of asynchronous processing: " 
										+ Thread.currentThread().getName());
			List<Product> prods = productDao.listProducts();
			//TimeUnit.SECONDS.sleep(10);
			asyncContext.complete();
			System.out.println("end of asynchronous processing");
			return prods;
		};
		
		Future<List<Product>> result = executor.submit(processList);
		try {
			List<Product> prodList = result.get();
			Jsonb jsonb = JsonbBuilder.create();
			String jsonData = jsonb.toJson(prodList);
			req.setAttribute("prodList", jsonData);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} 
		executor.shutdown();
		try {
			executor.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("end of servlet");
		req.getRequestDispatcher("/vid01/prod_list.jsp").forward(req, resp);
		
	}

}
