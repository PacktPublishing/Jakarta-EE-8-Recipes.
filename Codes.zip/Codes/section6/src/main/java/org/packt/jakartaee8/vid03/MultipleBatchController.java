package org.packt.jakartaee8.vid03;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/multbatch")
public class MultipleBatchController extends HttpServlet{
	
	private MultipleBatchProcessBean multBatchProcess;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			InitialContext jndi = new InitialContext();
			multBatchProcess = (MultipleBatchProcessBean)jndi.lookup("java:app/sec6/multBatchProcess");
			multBatchProcess.createBatches();
		} catch (NamingException e) {
			e.printStackTrace();
		}
	 resp.getWriter().println("triggered batch...");
	}

}
