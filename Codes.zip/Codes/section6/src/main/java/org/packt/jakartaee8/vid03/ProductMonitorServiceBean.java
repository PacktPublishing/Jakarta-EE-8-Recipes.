package org.packt.jakartaee8.vid03;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.LastExecution;
import javax.enterprise.concurrent.ManagedScheduledExecutorService;
import javax.enterprise.concurrent.Trigger;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import org.packt.jakartaee8.vid01.Product;
import org.packt.jakartaee8.vid01.ProductDao;

@Stateless(name="monitorService")
public class ProductMonitorServiceBean implements Serializable{
	
	@Resource(name="myJakartaEEScheduledMES")
	private ManagedScheduledExecutorService scheduledExecutor;
	
	@Inject
	@Named(value="productDao")
	private ProductDao productDao;
	
	@Inject
	private Event<ProductNotification> events;
	
	public void createTimedMonitoring() {
		Runnable updatedRecord = ()->{
			List<Product> prods = productDao.listProducts();
			events.fireAsync(new ProductNotification(prods));
		};
		
		Trigger trigger = new Trigger() {
			
            @Override
            public Date getNextRunTime(final LastExecution lastExecutionInfo, 
            		final Date taskScheduledTime) {
                if (lastExecutionInfo == null) {
                    return new Date();
                }
                LocalDateTime ldt = LocalDateTime.now().plusSeconds(5); 
                return Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant()); 
            }

            @Override
            public boolean skipRun(final LastExecution lastExecutionInfo, final Date scheduledRunTime) {
                return false;
            }
            
        };
		scheduledExecutor.schedule(updatedRecord, trigger);
	}
}
